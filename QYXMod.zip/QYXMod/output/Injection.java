// Add this to the game\'s MainActivity.onCreate()
try {
    // Load QYX library
    System.loadLibrary("QYX");
    
    // Start mod menu
    Class<?> menuClass = Class.forName("com.android.support.Main");
    Method startMethod = menuClass.getMethod("Start", Context.class);
    startMethod.invoke(null, this);
} catch (Exception e) {
    e.printStackTrace();
}
