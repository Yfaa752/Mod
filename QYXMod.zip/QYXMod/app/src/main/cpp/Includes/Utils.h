#ifndef UTILS_H
#define UTILS_H

#include <vector>
#include <string>
#include <sstream>

bool featureEnabled[20] = {false};
uintptr_t libBase = 0;

void PatchHex(void *addr, const char *hex) {
    // تنفيذ patch
}

void RestoreHex(void *addr) {
    // استرجاع القيمة الأصلية
}

void MSHookFunction(void *symbol, void *hook, void **original) {
    // تنفيذ hook
}

void TeleportToSafeZone() {
    // كود التليبورت
}

#endif

