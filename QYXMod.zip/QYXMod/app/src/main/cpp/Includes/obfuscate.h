#ifndef OBFUSCATE_H
#define OBFUSCATE_H

#define OBFUSCATE(str) str

#endif

