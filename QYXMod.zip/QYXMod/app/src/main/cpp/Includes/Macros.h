#ifndef MACROS_H
#define MACROS_H

#include <sys/mman.h>

// Page size for memory protection
#define PAGE_SIZE 4096

// ARM/ARM64 instructions
#define ARM_MOV_R0_0 0xE3A00000  // mov r0, #0
#define ARM_MOV_R0_1 0xE3A00001  // mov r0, #1
#define ARM_BX_LR    0xE12FFF1E  // bx lr
#define ARM_NOP      0xE320F000  // nop

#define ARM64_MOV_X0_0 0xD2800000  // mov x0, #0
#define ARM64_MOV_X0_1 0xD2800020  // mov x0, #1
#define ARM64_RET      0xD65F03C0  // ret
#define ARM64_NOP      0xD503201F  // nop

// Memory protection flags
#define PROT_RWX (PROT_READ | PROT_WRITE | PROT_EXEC)
#define PROT_RX  (PROT_READ | PROT_EXEC)

// Utility macros
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))
#define OFFSET_OF(type, member) ((size_t)&((type*)0)->member)

// String obfuscation
#define ENCRYPT_STR(str) str
#define DECRYPT_STR(str) str

// Debug macros
#ifdef DEBUG
    #define DEBUG_LOG(...) __android_log_print(ANDROID_LOG_DEBUG, "QYX_DEBUG", __VA_ARGS__)
#else
    #define DEBUG_LOG(...)
#endif

// Error handling
#define CHECK_NULL(ptr) \
    if ((ptr) == nullptr) { \
        LOGE("Null pointer at %s:%d", __FILE__, __LINE__); \
        return; \
    }

#define CHECK_RESULT(result) \
    if (!(result)) { \
        LOGE("Operation failed at %s:%d", __FILE__, __LINE__); \
        return false; \
    }

// Feature toggles
#define TOGGLE_FEATURE(feature_id, enabled) \
    g_features[feature_id].enabled = enabled; \
    LOGI("Feature %d: %s", feature_id, enabled ? "ON" : "OFF");

// Memory operations
#define READ_MEMORY(addr, type) (*(type*)(addr))
#define WRITE_MEMORY(addr, type, value) (*(type*)(addr) = (value))

// Hook macros
#define HOOK_FUNCTION(offset, hook, original) \
    MSHookFunction((void*)(base + offset), (void*)hook, (void**)&original)

#define PATCH_OFFSET(offset, hex) \
    PatchMemory(base + offset, hex)

// Game specific macros for Free Fire Max
#define PLAYER_STRUCT_SIZE 0x1000
#define WEAPON_STRUCT_SIZE 0x500
#define CAMERA_STRUCT_SIZE 0x300

// Offsets for Free Fire Max (update these based on game version)
#define OFFSET_PLAYER_HEALTH     0x100
#define OFFSET_PLAYER_ARMOR      0x104
#define OFFSET_PLAYER_POSITION   0x200
#define OFFSET_PLAYER_ROTATION   0x210
#define OFFSET_PLAYER_TEAM       0x300
#define OFFSET_PLAYER_NAME       0x400

#define OFFSET_WEAPON_AMMO       0x50
#define OFFSET_WEAPON_DAMAGE     0x60
#define OFFSET_WEAPON_RECOIL     0x70
#define OFFSET_WEAPON_FIRERATE   0x80

#define OFFSET_CAMERA_FOV        0x40
#define OFFSET_CAMERA_ZOOM       0x50
#define OFFSET_CAMERA_POSITION   0x60

#endif // MACROS_H

