#ifndef MENU_H
#define MENU_H

#include <jni.h>
#include <string>
#include <vector>

// Game offsets structure
struct GameOffsets {
    uintptr_t player_base;
    uintptr_t weapon_base;
    uintptr_t camera_base;
    uintptr_t network_base;
};

// Feature structure
struct Feature {
    int id;
    std::string name;
    bool enabled;
    int value;
    std::string text;
};

// Global variables
extern std::vector<Feature> g_features;
extern GameOffsets g_offsets;
extern bool g_initialized;

// Function declarations
void InitializeMenu();
void UpdateFeature(int id, bool enabled, int value, const char* text);
void ApplyPatches();
void RemovePatches();
void* GetGameLibraryHandle();
uintptr_t GetModuleBase(const char* library);
uintptr_t FindPattern(const char* pattern, const char* mask);

// Hook functions
void InstallHooks();
void UninstallHooks();

// Memory functions
void WriteMemory(uintptr_t address, void* buffer, size_t size);
void ReadMemory(uintptr_t address, void* buffer, size_t size);
void ProtectMemory(uintptr_t address, size_t size, int protection);

// Free Fire Max specific functions
void InitializeFFMaxOffsets();
void ApplyFFMaxPatches();
void EnableHeadshot(bool enable);
void EnableAimbot(bool enable);
void EnableNoRecoil(bool enable);
void EnableUnlimitedAmmo(bool enable);
void EnableSpeedHack(float multiplier);
void EnableJumpHack(float height);
void EnableWallhack(bool enable);
void EnableESP(bool players, bool items);
void SetFOV(float fov);
void TeleportPlayer(float x, float y, float z);
void ResetGuestAccount();

#endif // MENU_H

