#ifndef SETUP_H
#define SETUP_H

#include <pthread.h>
#include <jni.h>
#include <unistd.h>
#include <dlfcn.h>
#include <android/log.h>
#include <string>
#include <vector>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "QYX", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "QYX", __VA_ARGS__)

// Configuration
#define GAME_PACKAGE "com.dts.freefiremax"
#define GAME_LIB "libil2cpp.so"
#define MOD_VERSION "1.0.0"

// Memory patch structure
struct MemoryPatch {
    uintptr_t address;
    std::vector<uint8_t> original_bytes;
    std::vector<uint8_t> patched_bytes;
    bool is_applied;
    
    MemoryPatch(uintptr_t addr, const char* hex_patch) {
        address = addr;
        is_applied = false;
        ParseHexString(hex_patch, patched_bytes);
    }
    
    void ParseHexString(const char* hex, std::vector<uint8_t>& bytes) {
        std::string hex_str(hex);
        hex_str.erase(std::remove(hex_str.begin(), hex_str.end(), ' '), hex_str.end());
        
        for (size_t i = 0; i < hex_str.length(); i += 2) {
            std::string byte_str = hex_str.substr(i, 2);
            uint8_t byte = static_cast<uint8_t>(std::stoi(byte_str, nullptr, 16));
            bytes.push_back(byte);
        }
    }
    
    bool Apply() {
        if (is_applied) return true;
        
        // Save original bytes
        original_bytes.resize(patched_bytes.size());
        ReadMemory(address, original_bytes.data(), original_bytes.size());
        
        // Apply patch
        WriteMemory(address, patched_bytes.data(), patched_bytes.size());
        is_applied = true;
        
        return true;
    }
    
    bool Restore() {
        if (!is_applied) return true;
        
        // Restore original bytes
        WriteMemory(address, original_bytes.data(), original_bytes.size());
        is_applied = false;
        
        return true;
    }
    
    void ReadMemory(uintptr_t addr, void* buffer, size_t size) {
        memcpy(buffer, (void*)addr, size);
    }
    
    void WriteMemory(uintptr_t addr, void* buffer, size_t size) {
        // Make memory writable
        uintptr_t page_start = addr & ~(PAGE_SIZE - 1);
        mprotect((void*)page_start, PAGE_SIZE, PROT_READ | PROT_WRITE | PROT_EXEC);
        
        // Write memory
        memcpy((void*)addr, buffer, size);
        
        // Restore protection
        mprotect((void*)page_start, PAGE_SIZE, PROT_READ | PROT_EXEC);
    }
};

// Global patch list
std::vector<MemoryPatch*> g_patches;

// Initialize patches for Free Fire Max
void InitializePatches() {
    uintptr_t base = GetModuleBase(GAME_LIB);
    if (base == 0) {
        LOGE("Failed to get module base");
        return;
    }
    
    // Headshot patch
    g_patches.push_back(new MemoryPatch(base + 0x1234567, "01 00 A0 E3 1E FF 2F E1"));
    
    // No recoil patch
    g_patches.push_back(new MemoryPatch(base + 0x2345678, "00 00 A0 E3 1E FF 2F E1"));
    
    // Unlimited ammo patch
    g_patches.push_back(new MemoryPatch(base + 0x3456789, "FF FF A0 E3 1E FF 2F E1"));
    
    // Speed hack patch
    g_patches.push_back(new MemoryPatch(base + 0x4567890, "00 00 20 E3 1E FF 2F E1"));
    
    // Wallhack patch
    g_patches.push_back(new MemoryPatch(base + 0x5678901, "01 00 A0 E3 1E FF 2F E1"));
    
    LOGI("Patches initialized: %zu", g_patches.size());
}

// Wait for game library
void* WaitForLibrary(void* arg) {
    LOGI("Waiting for game library...");
    
    void* handle = nullptr;
    while (handle == nullptr) {
        handle = dlopen(GAME_LIB, RTLD_NOW);
        usleep(500000); // Wait 500ms
    }
    
    LOGI("Game library loaded!");
    
    // Initialize patches
    InitializePatches();
    
    // Initialize menu
    InitializeMenu();
    
    return nullptr;
}

// Get module base address
uintptr_t GetModuleBase(const char* library) {
    char filename[256];
    FILE* fp;
    uintptr_t address = 0;
    
    sprintf(filename, "/proc/self/maps");
    fp = fopen(filename, "r");
    
    if (fp != nullptr) {
        char line[512];
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, library)) {
                sscanf(line, "%lx", &address);
                break;
            }
        }
        fclose(fp);
    }
    
    return address;
}

#endif // SETUP_H

