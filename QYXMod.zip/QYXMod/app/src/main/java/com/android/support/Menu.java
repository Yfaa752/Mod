package com.android.support;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import android.media.MediaPlayer;

public class Menu extends Service {

    static {
        System.loadLibrary("QYX");
    }

    private native String Icon();
    private native String IconWebViewData();
    private native String[] getFeatureList();
    private native String[] getFeatureListDetails();
    private native boolean isGameLibLoaded();
    private native void settingsList(String[] listValue);
    private native void buttonAction(int featNum, String featName);
    public native void Changes(int featNum, String featName, int value, boolean bool, String str);

    private WindowManager windowManager;
    private View floatingView;
    private LinearLayout modMenu;
    private RelativeLayout iconLayout;
    private ImageView iconView;
    private LinearLayout menuLayout;
    private static Activity sActivity;
    
    public static void SetWindowManagerActivity(Activity activity) {
        sActivity = activity;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createFloatingView();
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadMod();
            }
        }, 1000);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void createFloatingView() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            LAYOUT_FLAG,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;

        // Create icon
        iconLayout = new RelativeLayout(this);
        iconView = new ImageView(this);
        iconView.setLayoutParams(new RelativeLayout.LayoutParams(100, 100));
        
        try {
            String iconData = Icon();
            if (iconData != null) {
                byte[] imageBytes = android.util.Base64.decode(iconData, android.util.Base64.DEFAULT);
                android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                iconView.setImageBitmap(bitmap);
            }
        } catch (Exception e) {
            iconView.setBackgroundColor(Color.RED);
        }

        iconLayout.addView(iconView);

        // Create menu
        modMenu = new LinearLayout(this);
        modMenu.setOrientation(LinearLayout.VERTICAL);
        modMenu.setBackgroundColor(Color.parseColor("#DD000000"));
        modMenu.setPadding(10, 10, 10, 10);
        modMenu.setVisibility(View.GONE);

        // Title
        TextView title = new TextView(this);
        title.setText("QYX MOD MENU");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        modMenu.addView(title);

        // Features scroll
        ScrollView scrollView = new ScrollView(this);
        menuLayout = new LinearLayout(this);
        menuLayout.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(menuLayout);
        modMenu.addView(scrollView);

        // Close button
        Button closeBtn = new Button(this);
        closeBtn.setText("CLOSE");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setBackgroundColor(Color.RED);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modMenu.setVisibility(View.GONE);
            }
        });
        modMenu.addView(closeBtn);

        // Icon click listener
        iconView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (modMenu.getVisibility() == View.GONE) {
                    modMenu.setVisibility(View.VISIBLE);
                } else {
                    modMenu.setVisibility(View.GONE);
                }
            }
        });

        // Make icon draggable
        iconView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(iconLayout, params);
                        windowManager.updateViewLayout(modMenu, params);
                        return false;
                }
                return false;
            }
        });

        windowManager.addView(iconLayout, params);
        windowManager.addView(modMenu, params);
    }

    private void loadMod() {
        String[] features = getFeatureList();
        if (features != null) {
            for (int i = 0; i < features.length; i++) {
                final int index = i;
                String feature = features[i];
                
                if (feature.contains("Toggle_")) {
                    addToggle(feature, index);
                } else if (feature.contains("Button_")) {
                    addButton(feature, index);
                } else if (feature.contains("SeekBar_")) {
                    addSeekBar(feature, index);
                } else if (feature.contains("InputText_")) {
                    addInputText(feature, index);
                }
            }
        }
    }

    private void addToggle(String feature, final int index) {
        String name = feature.replace("Toggle_", "");
        Switch switchView = new Switch(this);
        switchView.setText(name);
        switchView.setTextColor(Color.WHITE);
        switchView.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Changes(index, name, 0, isChecked, null);
            }
        });
        menuLayout.addView(switchView);
    }

    private void addButton(String feature, final int index) {
        String name = feature.replace("Button_", "");
        Button button = new Button(this);
        button.setText(name);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonAction(index, name);
            }
        });
        menuLayout.addView(button);
    }

    private void addSeekBar(String feature, final int index) {
        String[] parts = feature.split("_");
        String name = parts[1];
        int min = Integer.parseInt(parts[2]);
        int max = Integer.parseInt(parts[3]);
        
        TextView label = new TextView(this);
        label.setText(name + ": " + min);
        label.setTextColor(Color.WHITE);
        
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(max - min);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = min + progress;
                label.setText(name + ": " + value);
                Changes(index, name, value, false, null);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        menuLayout.addView(label);
        menuLayout.addView(seekBar);
    }

    private void addInputText(String feature, final int index) {
        String name = feature.replace("InputText_", "");
        
        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(Color.WHITE);
        
        EditText editText = new EditText(this);
        editText.setTextColor(Color.WHITE);
        editText.setHint("Enter value");
        
        Button applyBtn = new Button(this);
        applyBtn.setText("Apply");
        applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = editText.getText().toString();
                Changes(index, name, 0, false, text);
            }
        });
        
        menuLayout.addView(label);
        menuLayout.addView(editText);
        menuLayout.addView(applyBtn);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (iconLayout != null) windowManager.removeView(iconLayout);
        if (modMenu != null) windowManager.removeView(modMenu);
    }
}

