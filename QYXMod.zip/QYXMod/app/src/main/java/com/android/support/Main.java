package com.android.support;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

public class Main extends Activity {

    public static void StartWithoutPermission(Context context) {
        if (context instanceof Activity) {
            Menu.SetWindowManagerActivity((Activity) context);
        }
        context.startService(new Intent(context, Menu.class));
    }

    public static void Start(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            context.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, 
                Uri.parse("package:" + context.getPackageName())));
            Toast.makeText(context, "Please enable overlay permission", Toast.LENGTH_LONG).show();
            return;
        } else {
            StartWithoutPermission(context);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Start(this);
        finish();
    }
}

