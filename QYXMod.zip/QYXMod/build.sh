#!/bin/bash

echo "==================================="
echo "    QYX Mod Builder for FF Max    "
echo "==================================="

# Clean previous build
echo "[1/5] Cleaning previous build..."
./gradlew clean

# Build debug APK
echo "[2/5] Building APK..."
./gradlew assembleDebug

# Extract .so files
echo "[3/5] Extracting .so files..."
mkdir -p output/libs
cp -r app/build/intermediates/cmake/debug/obj/* output/libs/

# Copy XML config
echo "[4/5] Copying XML config..."
mkdir -p output/assets
cat > output/assets/qyx_config.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<qyx_config>
    <library>libQYX.so</library>
    <package>com.dts.freefiremax</package>
    <target>libil2cpp.so</target>
    <injection_point>onCreate</injection_point>
</qyx_config>
EOF

# Create injection code
echo "[5/5] Creating injection code..."
cat > output/Injection.java << 'EOF'
// Add this to the game\'s MainActivity.onCreate()
try {
    // Load QYX library
    System.loadLibrary("QYX");
    
    // Start mod menu
    Class<?> menuClass = Class.forName("com.android.support.Main");
    Method startMethod = menuClass.getMethod("Start", Context.class);
    startMethod.invoke(null, this);
} catch (Exception e) {
    e.printStackTrace();
}
EOF

echo "==================================="
echo "Build Complete!"
echo "Output files:"
echo "- Libraries: output/libs/"
echo "- Config: output/assets/qyx_config.xml"
echo "- Injection: output/Injection.java"
echo "==================================="

