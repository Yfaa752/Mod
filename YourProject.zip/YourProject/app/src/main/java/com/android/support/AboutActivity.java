package com.qyx.mod;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.util.Log;

public class AboutActivity extends AppCompatActivity {
    private static final String TAG = "QYX_About";

    private TextView versionText, buildText, descriptionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        initializeViews();
        loadAboutInfo();

        // Enable back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("About QYX Mod");
        }
    }

    private void initializeViews() {
        versionText = findViewById(R.id.version_text);
        buildText = findViewById(R.id.build_text);
        descriptionText = findViewById(R.id.description_text);
    }

    private void loadAboutInfo() {
        try {
            // Get version info from config
            com.android.support.Menu.QYXConfig config = com.android.support.Menu.getConfig();

            versionText.setText("Version: 1.0.0");
            buildText.setText("Build: 1");
            descriptionText.setText("QYX Mod for Standoff 2\n\n" +
									"Features:\n" +
									"• Wallhack\n" +
									"• Magic Bullet\n" +
									"• Auto Fire/Aim Assist\n" +
									"• Fast Reload\n" +
									"• ESP Lines/Boxes\n" +
									"• Speed Boost\n" +
									"• And more...\n\n" +
									"Target Game: Standoff 2\n" +
									"Compatible Android: 5.0+");

        } catch (Exception e) {
            Log.e(TAG, "Error loading about info", e);
            versionText.setText("Version: Unknown");
            buildText.setText("Build: Unknown");
            descriptionText.setText("QYX Mod for Standoff 2");
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
