package com.qyx.mod;

import android.content.Context;
import android.content.res.AssetManager;
import android.widget.Toast;
import android.util.Log;
import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Menu {
    private static final String TAG = "QYX_MOD";
    private static boolean isLibraryLoaded = false;

    static {
        try {
            System.loadLibrary("qyx_mod");
            isLibraryLoaded = true;
            Log.d(TAG, "QYX Library loaded successfully");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Failed to load QYX library: " + e.getMessage());
            isLibraryLoaded = false;
        }
    }

    // Native functions declarations
    public static native String[] getFeatureList();
    public static native void Changes(Context context, int featNum, String featName, 
                                      int value, long Lvalue, boolean enabled, String text);

    // Configuration class
    public static class QYXConfig {
        public String libraryName;
        public String gamePackage;
        public String targetLib;
        public String injectionMethod;
        public boolean obfuscationEnabled;
        public boolean antiDebugEnabled;
        public boolean rootDetectionEnabled;

        public QYXConfig() {
            // Default values
            this.libraryName = "libqyx_mod.so";
            this.gamePackage = "com.axlebolt.standoff2";
            this.targetLib = "libil2cpp.so";
            this.injectionMethod = "dlopen";
            this.obfuscationEnabled = true;
            this.antiDebugEnabled = true;
            this.rootDetectionEnabled = false;
        }
    }

    // Feature class
    public static class Feature {
        public int id;
        public String name;
        public String type;
        public boolean defaultValue;
        public boolean currentValue;

        public Feature() {
            this.id = 0;
            this.name = "";
            this.type = "toggle";
            this.defaultValue = false;
            this.currentValue = false;
        }

        public Feature(int id, String name, String type, boolean defaultValue) {
            this.id = id;
            this.name = name;
            this.type = type;
            this.defaultValue = defaultValue;
            this.currentValue = defaultValue;
        }
    }

    private static QYXConfig config = new QYXConfig();
    private static Feature[] features = new Feature[10];

    // Initialize QYX Mod System
    public static boolean initializeQYX(Context context) {
        if (!isLibraryLoaded) {
            Log.e(TAG, "Cannot initialize QYX - library not loaded");
            return false;
        }

        try {
            // Load configuration from assets
            loadConfigFromAssets(context);

            // Initialize features
            initializeFeatures();

            Log.d(TAG, "QYX System initialized successfully");
            return true;

        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize QYX: " + e.getMessage());
            return false;
        }
    }

    // Load configuration from XML file in assets
    public static void loadConfigFromAssets(Context context) {
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open("qyx_config.xml");

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(inputStream);

            processConfig(document);

            inputStream.close();
            Log.d(TAG, "Configuration loaded from assets");

        } catch (Exception e) {
            Log.e(TAG, "Failed to load config from assets: " + e.getMessage());
            // Use default configuration
            setDefaultConfig();
        }
    }

    // Process XML configuration
    private static void processConfig(Document doc) {
        try {
            // Parse settings
            NodeList settingsNodes = doc.getElementsByTagName("settings");
            if (settingsNodes.getLength() > 0) {
                Element settings = (Element) settingsNodes.item(0);

                config.libraryName = getElementValue(settings, "library_name", "libqyx_mod.so");
                config.gamePackage = getElementValue(settings, "game_package", "com.axlebolt.standoff2");
                config.targetLib = getElementValue(settings, "target_lib", "libil2cpp.so");
                config.injectionMethod = getElementValue(settings, "injection_method", "dlopen");
            }

            // Parse protection settings
            NodeList protectionNodes = doc.getElementsByTagName("protection");
            if (protectionNodes.getLength() > 0) {
                Element protection = (Element) protectionNodes.item(0);

                config.obfuscationEnabled = getBooleanAttribute(protection, "obfuscation", "enabled", true);
                config.antiDebugEnabled = getBooleanAttribute(protection, "anti_debug", "enabled", true);
                config.rootDetectionEnabled = getBooleanAttribute(protection, "root_detection", "enabled", false);
            }

            // Parse features
            NodeList featureNodes = doc.getElementsByTagName("feature");
            for (int i = 0; i < featureNodes.getLength() && i < features.length; i++) {
                Element featureElement = (Element) featureNodes.item(i);

                Feature feature = new Feature();
                feature.id = Integer.parseInt(featureElement.getAttribute("id"));
                feature.name = featureElement.getAttribute("name");
                feature.type = featureElement.getAttribute("type");
                feature.defaultValue = Boolean.parseBoolean(featureElement.getAttribute("default"));
                feature.currentValue = feature.defaultValue;

                features[i] = feature;
            }

        } catch (Exception e) {
            Log.e(TAG, "Error processing config: " + e.getMessage());
            setDefaultConfig();
        }
    }

    // Helper methods for XML parsing
    private static String getElementValue(Element parent, String tagName, String defaultValue) {
        try {
            NodeList nodeList = parent.getElementsByTagName(tagName);
            if (nodeList.getLength() > 0) {
                return nodeList.item(0).getTextContent();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting element value for " + tagName + ": " + e.getMessage());
        }
        return defaultValue;
    }

    private static boolean getBooleanAttribute(Element parent, String tagName, String attributeName, boolean defaultValue) {
        try {
            NodeList nodeList = parent.getElementsByTagName(tagName);
            if (nodeList.getLength() > 0) {
                Element element = (Element) nodeList.item(0);
                String value = element.getAttribute(attributeName);
                return Boolean.parseBoolean(value);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting boolean attribute: " + e.getMessage());
        }
        return defaultValue;
    }

    // Set default configuration if XML loading fails
    private static void setDefaultConfig() {
        config.libraryName = "libqyx_mod.so";
        config.gamePackage = "com.axlebolt.standoff2";
        config.targetLib = "libil2cpp.so";
        config.injectionMethod = "dlopen";
        config.obfuscationEnabled = true;
        config.antiDebugEnabled = true;
        config.rootDetectionEnabled = false;

        Log.d(TAG, "Using default configuration");
    }

    // Initialize features with default values
    private static void initializeFeatures() {
        String[] featureNames = {
            "Enable QYX",
            "Wallhack", 
            "Magic Bullet",
            "Player Speed",
            "ESP Line/Box",
            "Fast Switch Gun",
            "Reset Guest",
            "Auto Fire / Aim Assist",
            "Weapon Run Speed",
            "Fast Auto Reload"
        };

        // If features weren't loaded from XML, create default ones
        for (int i = 0; i < featureNames.length; i++) {
            if (features[i] == null) {
                features[i] = new Feature(i, featureNames[i], "toggle", false);
            }
        }
    }

    // Toggle feature on/off
    public static void toggleFeature(Context context, int featureId, boolean enabled) {
        if (!isLibraryLoaded) {
            showToast(context, "QYX Library not loaded!");
            return;
        }

        if (featureId >= 0 && featureId < features.length && features[featureId] != null) {
            features[featureId].currentValue = enabled;

            // Call native function
            Changes(context, featureId, features[featureId].name, 0, 0, enabled, "");

            String status = enabled ? "Enabled" : "Disabled";
            Log.d(TAG, "Feature " + features[featureId].name + " " + status);

        } else {
            Log.e(TAG, "Invalid feature ID: " + featureId);
        }
    }

    // Get feature status
    public static boolean getFeatureStatus(int featureId) {
        if (featureId >= 0 && featureId < features.length && features[featureId] != null) {
            return features[featureId].currentValue;
        }
        return false;
    }

    // Get feature name
    public static String getFeatureName(int featureId) {
        if (featureId >= 0 && featureId < features.length && features[featureId] != null) {
            return features[featureId].name;
        }
        return "Unknown Feature";
    }

    // Get all features
    public static Feature[] getAllFeatures() {
        return features;
    }

    // Get configuration
    public static QYXConfig getConfig() {
        return config;
    }

    // Show toast message
    private static void showToast(Context context, String message) {
        if (context != null) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }
    }

    // Check if library is loaded
    public static boolean isLibraryLoaded() {
        return isLibraryLoaded;
    }

    // Enable QYX system (master toggle)
    public static void enableQYXSystem(Context context, boolean enable) {
        toggleFeature(context, 0, enable);

        String message = enable ? "QYX System Activated" : "QYX System Deactivated";
        showToast(context, message);
        Log.d(TAG, message);
    }

    // Quick enable common features
    public static void enableCommonFeatures(final Context context) {
        if (!isLibraryLoaded) {
            showToast(context, "QYX Library not loaded!");
            return;
        }

        // Enable QYX system first
        enableQYXSystem(context, true);

        // Wait a bit for system initialization
        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						Thread.sleep(500);

						// Enable common features
						toggleFeature(context, 7, true); // Auto Fire
						toggleFeature(context, 5, true); // Fast Switch
						toggleFeature(context, 9, true); // Fast Reload

						Log.d(TAG, "Common features enabled");

					} catch (InterruptedException e) {
						Log.e(TAG, "Thread interrupted: " + e.getMessage());
					}
				}
			}).start();
    }
}
