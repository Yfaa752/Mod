package com.android.support;

import android.content.Context;
import android.content.res.AssetManager;
import android.widget.Toast;
import android.util.Log;
import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Menu {
    private static final String TAG = "QYX_Menu";
    private static boolean isLibraryLoaded = false;
    private static boolean isSystemInitialized = false;

    static {
        try {
            System.loadLibrary("qyx_mod");
            isLibraryLoaded = true;
            Log.d(TAG, "QYX Native library loaded successfully");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Failed to load QYX native library: " + e.getMessage());
            isLibraryLoaded = false;
        }
    }

    // Native function declarations
    public static native String[] getFeatureList();
    public static native void Changes(Context context, int featNum, String featName, 
									  int value, long Lvalue, boolean enabled, String text);
    public static native void initializeNativeSystem();
    public static native void destroyNativeSystem();

    // Configuration class
    public static class QYXConfig {
        public String libraryName = "libqyx_mod.so";
        public String gamePackage = "com.axlebolt.standoff2";
        public String targetLib = "libil2cpp.so";
        public String injectionMethod = "dlopen";
        public boolean obfuscationEnabled = true;
        public boolean antiDebugEnabled = true;
        public boolean rootDetectionEnabled = false;
        public int initializationDelay = 3000;
        public int featureActivationDelay = 500;
    }

    // Feature class
    public static class Feature {
        public int id;
        public String name;
        public String type;
        public boolean defaultValue;
        public boolean currentValue;
        public String description;
        public String category;
        public boolean requiresSystem;

        public Feature() {
            this.id = -1;
            this.name = "Unknown";
            this.type = "toggle";
            this.defaultValue = false;
            this.currentValue = false;
            this.description = "";
            this.category = "general";
            this.requiresSystem = true;
        }
    }

    private static QYXConfig config = new QYXConfig();
    private static Feature[] features = new Feature[10];

    // Initialize QYX System
    public static boolean initializeQYX(Context context) {
        if (!isLibraryLoaded) {
            Log.e(TAG, "Cannot initialize QYX - native library not loaded");
            return false;
        }

        if (isSystemInitialized) {
            Log.d(TAG, "QYX System already initialized");
            return true;
        }

        try {
            // Load configuration from assets
            loadConfigFromAssets(context);

            // Initialize features
            initializeFeatures();

            // Initialize native system
            if (isLibraryLoaded) {
                initializeNativeSystem();
            }

            isSystemInitialized = true;
            Log.d(TAG, "QYX System initialized successfully");
            return true;

        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize QYX System: " + e.getMessage());
            isSystemInitialized = false;
            return false;
        }
    }

    // Load configuration from XML file in assets
    public static void loadConfigFromAssets(Context context) {
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open("qyx_config.xml");

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(inputStream);

            processConfig(document);

            inputStream.close();
            Log.d(TAG, "Configuration loaded from assets successfully");

        } catch (Exception e) {
            Log.e(TAG, "Failed to load config from assets: " + e.getMessage());
            // Use default configuration
            setDefaultConfig();
        }
    }

    // Process XML configuration
    private static void processConfig(Document doc) {
        try {
            doc.getDocumentElement().normalize();

            // Parse settings
            NodeList settingsNodes = doc.getElementsByTagName("settings");
            if (settingsNodes.getLength() > 0) {
                Element settings = (Element) settingsNodes.item(0);

                config.libraryName = getElementValue(settings, "library_name", config.libraryName);
                config.gamePackage = getElementValue(settings, "game_package", config.gamePackage);
                config.targetLib = getElementValue(settings, "target_lib", config.targetLib);
                config.injectionMethod = getElementValue(settings, "injection_method", config.injectionMethod);

                String delayStr = getElementValue(settings, "initialization_delay", "3000");
                config.initializationDelay = Integer.parseInt(delayStr);

                String activationDelayStr = getElementValue(settings, "feature_activation_delay", "500");
                config.featureActivationDelay = Integer.parseInt(activationDelayStr);
            }

            // Parse protection settings
            NodeList protectionNodes = doc.getElementsByTagName("protection");
            if (protectionNodes.getLength() > 0) {
                Element protection = (Element) protectionNodes.item(0);

                config.obfuscationEnabled = getBooleanAttribute(protection, "obfuscation", "enabled", true);
                config.antiDebugEnabled = getBooleanAttribute(protection, "anti_debug", "enabled", true);
                config.rootDetectionEnabled = getBooleanAttribute(protection, "root_detection", "enabled", false);
            }

            // Parse features
            NodeList featureNodes = doc.getElementsByTagName("feature");
            for (int i = 0; i < featureNodes.getLength() && i < features.length; i++) {
                Element featureElement = (Element) featureNodes.item(i);

                Feature feature = new Feature();

                try {
                    feature.id = Integer.parseInt(featureElement.getAttribute("id"));
                    feature.name = featureElement.getAttribute("name");
                    feature.type = featureElement.getAttribute("type");
                    feature.defaultValue = Boolean.parseBoolean(featureElement.getAttribute("default"));
                    feature.currentValue = feature.defaultValue;
                    feature.description = featureElement.getAttribute("description");
                    feature.category = featureElement.getAttribute("category");
                    feature.requiresSystem = Boolean.parseBoolean(
                        featureElement.getAttribute("requires_system"));

                    features[feature.id] = feature;

                } catch (NumberFormatException e) {
                    Log.e(TAG, "Invalid feature ID format: " + e.getMessage());
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing feature: " + e.getMessage());
                }
            }

            Log.d(TAG, "Configuration processed successfully");

        } catch (Exception e) {
            Log.e(TAG, "Error processing XML configuration: " + e.getMessage());
            setDefaultConfig();
        }
    }

    // Helper methods for XML parsing
    private static String getElementValue(Element parent, String tagName, String defaultValue) {
        try {
            NodeList nodeList = parent.getElementsByTagName(tagName);
            if (nodeList.getLength() > 0) {
                String value = nodeList.item(0).getTextContent();
                return value != null && !value.trim().isEmpty() ? value.trim() : defaultValue;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting element value for " + tagName + ": " + e.getMessage());
        }
        return defaultValue;
    }

    private static boolean getBooleanAttribute(Element parent, String tagName, 
											   String attributeName, boolean defaultValue) {
        try {
            NodeList nodeList = parent.getElementsByTagName(tagName);
            if (nodeList.getLength() > 0) {
                Element element = (Element) nodeList.item(0);
                String value = element.getAttribute(attributeName);
                if (value != null && !value.isEmpty()) {
                    return Boolean.parseBoolean(value);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting boolean attribute: " + e.getMessage());
        }
        return defaultValue;
    }

    // Set default configuration if XML loading fails
    private static void setDefaultConfig() {
        config = new QYXConfig(); // Reset to defaults
        Log.d(TAG, "Using default configuration");
    }

    // Initialize features with default values
    private static void initializeFeatures() {
        String[] featureNames = {
            "Enable QYX",
            "Wallhack", 
            "Magic Bullet",
            "Player Speed",
            "ESP Line/Box",
            "Fast Switch Gun",
            "Reset Guest",
            "Auto Fire / Aim Assist",
            "Weapon Run Speed",
            "Fast Auto Reload"
        };

        String[] descriptions = {
            "Master toggle for QYX system",
            "See through walls and obstacles",
            "Bullets go through walls and hit enemies",
            "Increase player movement speed",
            "Show enemy positions with lines and boxes",
            "Instantly switch between weapons",
            "Reset guest account progress",
            "Automatically fire at enemies",
            "Increase movement speed while holding weapons",
            "Reload weapons much faster"
        };

        String[] categories = {
            "system", "visual", "combat", "movement", "visual",
            "combat", "utility", "combat", "movement", "combat"
        };

        // Create default features if not loaded from XML
        for (int i = 0; i < featureNames.length; i++) {
            if (features[i] == null) {
                Feature feature = new Feature();
                feature.id = i;
                feature.name = featureNames[i];
                feature.type = "toggle";
                feature.defaultValue = false;
                feature.currentValue = false;
                feature.description = descriptions[i];
                feature.category = categories[i];
                feature.requiresSystem = (i != 0); // System toggle doesn't require itself

                features[i] = feature;
            }
        }

        Log.d(TAG, "Features initialized with " + featureNames.length + " features");
    }

    // Toggle feature on/off
    public static void toggleFeature(Context context, int featureId, boolean enabled) {
        if (!isLibraryLoaded) {
            showToast(context, "QYX Native library not loaded!");
            return;
        }

        if (featureId < 0 || featureId >= features.length || features[featureId] == null) {
            Log.e(TAG, "Invalid feature ID: " + featureId);
            return;
        }

        Feature feature = features[featureId];

        // Check if system is required and enabled
        if (feature.requiresSystem && !getFeatureStatus(0) && featureId != 0) {
            showToast(context, "Please enable QYX System first!");
            return;
        }

        try {
            // Update feature state
            feature.currentValue = enabled;

            // Call native function if library is loaded
            if (isLibraryLoaded) {
                Changes(context, featureId, feature.name, 0, 0, enabled, "");
            }

            String status = enabled ? "Enabled" : "Disabled";
            Log.d(TAG, "Feature '" + feature.name + "' " + status);

            // Show feedback to user
            showToast(context, feature.name + " " + status);

        } catch (Exception e) {
            Log.e(TAG, "Error toggling feature " + feature.name + ": " + e.getMessage());
            // Revert state on error
            feature.currentValue = !enabled;
            showToast(context, "Error toggling " + feature.name);
        }
    }

    // Get feature status
    public static boolean getFeatureStatus(int featureId) {
        if (featureId >= 0 && featureId < features.length && features[featureId] != null) {
            return features[featureId].currentValue;
        }
        return false;
    }

    // Get feature name
    public static String getFeatureName(int featureId) {
        if (featureId >= 0 && featureId < features.length && features[featureId] != null) {
            return features[featureId].name;
        }
        return "Unknown Feature";
    }

    // Get all features
    public static Feature[] getAllFeatures() {
        return features;
    }

    // Get configuration
    public static QYXConfig getConfig() {
        return config;
    }

    // Show toast message safely
    private static void showToast(Context context, String message) {
        if (context != null) {
            try {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "Error showing toast: " + e.getMessage());
            }
        }
    }

    // Check if library is loaded
    public static boolean isLibraryLoaded() {
        return isLibraryLoaded;
    }

    // Check if system is initialized
    public static boolean isSystemInitialized() {
        return isSystemInitialized;
    }

    // Enable QYX system (master toggle)
    public static void enableQYXSystem(Context context, boolean enable) {
        if (!isLibraryLoaded) {
            showToast(context, "QYX Native library not loaded!");
            return;
        }

        if (!isSystemInitialized && enable) {
            showToast(context, "QYX System not initialized!");
            return;
        }

        try {
            toggleFeature(context, 0, enable);

            String message = enable ? "QYX System Activated" : "QYX System Deactivated";
            showToast(context, message);
            Log.d(TAG, message);

            // If disabling, turn off all other features
            if (!enable) {
                for (int i = 1; i < features.length; i++) {
                    if (features[i] != null && features[i].currentValue) {
                        toggleFeature(context, i, false);
                    }
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Error toggling QYX system: " + e.getMessage());
            showToast(context, "Error toggling QYX system");
        }
    }

    // Quick enable common features
    public static void enableCommonFeatures(Context context) {
        if (!isLibraryLoaded) {
            showToast(context, "QYX Native library not loaded!");
            return;
        }

        if (!isSystemInitialized) {
            showToast(context, "QYX System not initialized!");
            return;
        }

        try {
            // Enable QYX system first
            enableQYXSystem(context, true);

            // Wait for system initialization
            new Thread(() -> {
                try {
                    Thread.sleep(config.featureActivationDelay);

                    // Enable common features
                    toggleFeature(context, 7, true); // Auto Fire
                    Thread.sleep(100);
                    toggleFeature(context, 5, true); // Fast Switch
                    Thread.sleep(100);
                    toggleFeature(context, 9, true); // Fast Reload

                    Log.d(TAG, "Common features enabled successfully");

                } catch (InterruptedException e) {
                    Log.e(TAG, "Thread interrupted: " + e.getMessage());
                } catch (Exception e) {
                    Log.e(TAG, "Error enabling common features: " + e.getMessage());
                }
            }).start();

        } catch (Exception e) {
            Log.e(TAG, "Error in enableCommonFeatures: " + e.getMessage());
            showToast(context, "Error enabling common features");
        }
    }

    // Disable all features
    public static void disableAllFeatures(Context context) {
        try {
            for (int i = 0; i < features.length; i++) {
                if (features[i] != null && features[i].currentValue) {
                    toggleFeature(context, i, false);
                }
            }
            Log.d(TAG, "All features disabled");
            showToast(context, "All features disabled");
        } catch (Exception e) {
            Log.e(TAG, "Error disabling all features: " + e.getMessage());
        }
    }

    // Get feature by ID safely
    public static Feature getFeature(int featureId) {
        if (featureId >= 0 && featureId < features.length) {
            return features[featureId];
        }
        return null;
    }

    // Get features by category
    public static Feature[] getFeaturesByCategory(String category) {
        java.util.List<Feature> categoryFeatures = new java.util.ArrayList<>();

        for (Feature feature : features) {
            if (feature != null && feature.category.equals(category)) {
                categoryFeatures.add(feature);
            }
        }

        return categoryFeatures.toArray(new Feature[0]);
    }

    // System cleanup
    public static void cleanup() {
        try {
            if (isLibraryLoaded && isSystemInitialized) {
                destroyNativeSystem();
            }
            isSystemInitialized = false;
            Log.d(TAG, "QYX System cleaned up");
        } catch (Exception e) {
            Log.e(TAG, "Error during cleanup: " + e.getMessage());
        }
    }
}
