package com.qyx.mod;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

public class QYXBroadcastReceiver extends BroadcastReceiver {

    private static final String TAG = "QYXBroadcastReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "Received broadcast: " + action);

        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            // Start QYX service on boot
            Log.d(TAG, "Boot completed, starting QYX service");
            startQYXService(context);

        } else if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(action) || 
                   Intent.ACTION_PACKAGE_REPLACED.equals(action)) {
            // Restart service after app update
            Log.d(TAG, "Package replaced, restarting QYX service");
            startQYXService(context);
        }
    }

    private void startQYXService(Context context) {
        try {
            Intent serviceIntent = new Intent(context, QYXService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
            Log.d(TAG, "QYX service started successfully");
        } catch (Exception e) {
            Log.e(TAG, "Failed to start QYX service: " + e.getMessage());
        }
    }
}
