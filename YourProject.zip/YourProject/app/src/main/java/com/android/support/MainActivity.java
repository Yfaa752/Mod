package com.qyx.mod;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.Manifest;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "QYX_MainActivity";
    private static final int PERMISSION_REQUEST_CODE = 1001;

    private TextView statusText;
    private Button aboutButton, settingsButton;
    private Switch masterToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        checkPermissions();
        initializeQYX();
    }

    private void initializeViews() {
        statusText = findViewById(R.id.status_text);
        aboutButton = findViewById(R.id.about_button);
        settingsButton = findViewById(R.id.settings_button);
        masterToggle = findViewById(R.id.master_toggle);

        // Set click listeners
        aboutButton.setOnClickListener(v -> openAboutActivity());
        settingsButton.setOnClickListener(v -> openSettingsActivity());
        masterToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                enableQYXSystem();
            } else {
                disableQYXSystem();
            }
        });
    }

    private void checkPermissions() {
        String[] permissions = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        };

        boolean needsPermission = false;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) 
                != PackageManager.PERMISSION_GRANTED) {
                needsPermission = true;
                break;
            }
        }

        if (needsPermission) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    private void initializeQYX() {
        try {
            boolean success = com.android.support.Menu.initializeQYX(this);
            if (success) {
                statusText.setText("QYX System Ready");
                Log.d(TAG, "QYX initialized successfully");
            } else {
                statusText.setText("QYX Initialization Failed");
                Log.e(TAG, "Failed to initialize QYX");
            }
        } catch (Exception e) {
            statusText.setText("Error: " + e.getMessage());
            Log.e(TAG, "Exception during QYX initialization", e);
        }
    }

    private void enableQYXSystem() {
        try {
            com.android.support.Menu.enableQYXSystem(this, true);
            statusText.setText("QYX System Activated");
            showToast("QYX System Enabled");
        } catch (Exception e) {
            statusText.setText("Failed to enable QYX");
            showToast("Error enabling QYX: " + e.getMessage());
        }
    }

    private void disableQYXSystem() {
        try {
            com.android.support.Menu.enableQYXSystem(this, false);
            statusText.setText("QYX System Deactivated");
            showToast("QYX System Disabled");
        } catch (Exception e) {
            statusText.setText("Failed to disable QYX");
            showToast("Error disabling QYX: " + e.getMessage());
        }
    }

    private void openAboutActivity() {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }

    private void openSettingsActivity() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (!allGranted) {
                showToast("Permissions required for proper functioning");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }

    private void updateUI() {
        try {
            boolean isEnabled = com.android.support.Menu.getFeatureStatus(0);
            masterToggle.setChecked(isEnabled);

            if (isEnabled) {
                statusText.setText("QYX System Active");
            } else {
                statusText.setText("QYX System Inactive");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating UI", e);
        }
    }
}
