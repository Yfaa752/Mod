package com.qyx.mod;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.view.View;

public class SettingsActivity extends AppCompatActivity {
    private static final String TAG = "QYX_Settings";

    private LinearLayout featuresContainer;
    private Switch[] featureSwitches;
    private TextView[] featureLabels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("QYX Settings");
        }

        initializeViews();
        loadFeatures();
    }

    private void initializeViews() {
        featuresContainer = findViewById(R.id.features_container);
    }

    private void loadFeatures() {
        try {
            com.android.support.Menu.Feature[] features = com.android.support.Menu.getAllFeatures();

            if (features == null || features.length == 0) {
                showToast("No features available");
                return;
            }

            featureSwitches = new Switch[features.length];
            featureLabels = new TextView[features.length];

            for (int i = 0; i < features.length; i++) {
                if (features[i] != null) {
                    createFeatureToggle(features[i], i);
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Error loading features", e);
            showToast("Error loading features");
        }
    }

    private void createFeatureToggle(com.android.support.Menu.Feature feature, int index) {
        // Create container for this feature
        LinearLayout featureLayout = new LinearLayout(this);
        featureLayout.setOrientation(LinearLayout.HORIZONTAL);
        featureLayout.setPadding(16, 8, 16, 8);

        // Create label
        TextView label = new TextView(this);
        label.setText(feature.name);
        label.setTextSize(16);
        label.setLayoutParams(new LinearLayout.LayoutParams(
								  0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

        // Create switch
        Switch toggle = new Switch(this);
        toggle.setChecked(feature.currentValue);
        toggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            try {
                com.android.support.Menu.toggleFeature(this, feature.id, isChecked);
                String status = isChecked ? "Enabled" : "Disabled";
                showToast(feature.name + " " + status);
            } catch (Exception e) {
                Log.e(TAG, "Error toggling feature " + feature.name, e);
                showToast("Error toggling " + feature.name);
                // Revert switch state
                buttonView.setChecked(!isChecked);
            }
        });

        // Add views to layout
        featureLayout.addView(label);
        featureLayout.addView(toggle);

        // Add to main container
        featuresContainer.addView(featureLayout);

        // Store references
        featureSwitches[index] = toggle;
        featureLabels[index] = label;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateFeatureStates();
    }

    private void updateFeatureStates() {
        try {
            com.android.support.Menu.Feature[] features = com.android.support.Menu.getAllFeatures();

            for (int i = 0; i < features.length && i < featureSwitches.length; i++) {
                if (features[i] != null && featureSwitches[i] != null) {
                    featureSwitches[i].setChecked(features[i].currentValue);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating feature states", e);
        }
    }
}
