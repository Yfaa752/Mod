package com.qyx.mod;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

public class QYXContentProvider extends ContentProvider {

    private static final String TAG = "QYXContentProvider";

    @Override
    public boolean onCreate() {
        Log.d(TAG, "QYXContentProvider created");
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, 
                        String[] selectionArgs, String sortOrder) {
        Log.d(TAG, "Query called: " + uri);
        return null; // Not implemented for security
    }

    @Override
    public String getType(Uri uri) {
        return null; // Not used
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Log.d(TAG, "Insert called: " + uri);
        return null; // Not implemented for security
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        Log.d(TAG, "Delete called: " + uri);
        return 0; // Not implemented for security
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, 
                      String[] selectionArgs) {
        Log.d(TAG, "Update called: " + uri);
        return 0; // Not implemented for security
    }
}
