#ifndef MACROS_H
#define MACROS_H

#include <cstdint>
#include <cstring>

// ماكرو للإصدار والمعلومات
#define QYX_VERSION "1.0.0"
#define QYX_BUILD_DATE __DATE__ " " __TIME__
#define QYX_AUTHOR "QYX Team"

// ماكرو للمعمارية
#ifdef __aarch64__
    #define TARGET_ARCH "arm64-v8a"
    #define ARCH_64BIT
#elif defined(__arm__)
    #define TARGET_ARCH "armeabi-v7a"
    #define ARCH_32BIT
#else
    #define TARGET_ARCH "unknown"
#endif

// ماكرو للتصحيح
#ifdef DEBUG
    #define QYX_DEBUG 1
    #define DEBUG_BREAK() __builtin_trap()
#else
    #define QYX_DEBUG 0
    #define DEBUG_BREAK() do {} while(0)
#endif

// ماكرو للتحسين
#define FORCE_INLINE __attribute__((always_inline)) inline
#define NO_INLINE __attribute__((noinline))
#define LIKELY(x) __builtin_expect(!!(x), 1)
#define UNLIKELY(x) __builtin_expect(!!(x), 0)

// ماكرو للذاكرة
#define ALIGN(x, a) (((x) + (a) - 1) & ~((a) - 1))
#define PAGE_SIZE 4096
#define PAGE_ALIGN(x) ALIGN(x, PAGE_SIZE)

// ماكرو للبايتات
#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte) \
    (byte & 0x80 ? '1' : '0'), \
    (byte & 0x40 ? '1' : '0'), \
    (byte & 0x20 ? '1' : '0'), \
    (byte & 0x10 ? '1' : '0'), \
    (byte & 0x08 ? '1' : '0'), \
    (byte & 0x04 ? '1' : '0'), \
    (byte & 0x02 ? '1' : '0'), \
    (byte & 0x01 ? '1' : '0')

// ماكرو للعناوين
#define PTR_TO_UINT(ptr) ((uintptr_t)(ptr))
#define UINT_TO_PTR(addr) ((void*)(addr))
#define OFFSET_PTR(ptr, offset) ((void*)((uintptr_t)(ptr) + (offset)))

// ماكرو للبتات
#define SET_BIT(value, bit) ((value) |= (1 << (bit)))
#define CLEAR_BIT(value, bit) ((value) &= ~(1 << (bit)))
#define TOGGLE_BIT(value, bit) ((value) ^= (1 << (bit)))
#define CHECK_BIT(value, bit) (((value) >> (bit)) & 1)

// ماكرو للحد الأدنى والأقصى
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define CLAMP(value, min_val, max_val) MIN(MAX(value, min_val), max_val)

// ماكرو للمصفوفات
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#define ARRAY_END(arr) ((arr) + ARRAY_SIZE(arr))

// ماكرو للنصوص
#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)
#define CONCAT(a, b) a##b

// ماكرو للتحقق من الأخطاء
#define CHECK_NULL(ptr) \
    do { \
        if (UNLIKELY((ptr) == nullptr)) { \
            LOGE("Null pointer check failed: %s", #ptr); \
            return false; \
        } \
    } while(0)

#define CHECK_NULL_RET(ptr, ret) \
    do { \
        if (UNLIKELY((ptr) == nullptr)) { \
            LOGE("Null pointer check failed: %s", #ptr); \
            return ret; \
        } \
    } while(0)

#define CHECK_BOUNDS(index, size) \
    do { \
        if (UNLIKELY((index) >= (size))) { \
            LOGE("Bounds check failed: %zu >= %zu", (size_t)(index), (size_t)(size)); \
            return false; \
        } \
    } while(0)

// ماكرو للتوقيت
#define BENCHMARK_START(name) \
    struct timespec start_##name; \
    clock_gettime(CLOCK_MONOTONIC, &start_##name)

#define BENCHMARK_END(name) \
    do { \
        struct timespec end_##name; \
        clock_gettime(CLOCK_MONOTONIC, &end_##name); \
        long diff_ns = (end_##name.tv_sec - start_##name.tv_sec) * 1000000000L + \
                       (end_##name.tv_nsec - start_##name.tv_nsec); \
        LOGD("BENCHMARK %s: %ld ns (%.3f ms)", #name, diff_ns, diff_ns / 1000000.0); \
    } while(0)

// ماكرو للحماية
#define ANTI_TAMPER_CHECK(expected_checksum) \
    do { \
        uint32_t current_checksum = calculate_code_checksum(); \
        if (UNLIKELY(current_checksum != (expected_checksum))) { \
            LOGE("Anti-tamper check failed!"); \
            exit(1); \
        } \
    } while(0)

// ماكرو للتشفير
#define XOR_ENCRYPT(data, size, key) \
    do { \
        for (size_t i = 0; i < (size); ++i) { \
            ((uint8_t*)(data))[i] ^= (key) ^ (i & 0xFF); \
        } \
    } while(0)

#define XOR_DECRYPT(data, size, key) XOR_ENCRYPT(data, size, key)

// ماكرو للتحكم في التدفق
#define GOTO_IF(condition, label) \
    do { \
        if (UNLIKELY(condition)) { \
            goto label; \
        } \
    } while(0)

#define RETURN_IF(condition, value) \
    do { \
        if (UNLIKELY(condition)) { \
            return value; \
        } \
    } while(0)

#define BREAK_IF(condition) \
    if (UNLIKELY(condition)) break

#define CONTINUE_IF(condition) \
    if (UNLIKELY(condition)) continue

// ماكرو للحلقات
#define FOR_EACH_BIT(var, value) \
    for (int var = 0; var < (sizeof(value) * 8); ++var) \
        if (CHECK_BIT(value, var))

#define REPEAT(n) \
    for (int _repeat_counter = 0; _repeat_counter < (n); ++_repeat_counter)

// ماكرو للهياكل
#define STRUCT_OFFSET(type, member) ((size_t)&(((type*)0)->member))
#define CONTAINER_OF(ptr, type, member) \
    ((type*)((char*)(ptr) - STRUCT_OFFSET(type, member)))

// ماكرو للتحويل الآمن
#define SAFE_CAST(type, value) \
    ({ \
        static_assert(sizeof(type) >= sizeof(typeof(value)), "Unsafe cast"); \
        (type)(value); \
    })

// ماكرو للذاكرة المؤقتة
#define STACK_BUFFER(name, size) \
    uint8_t name[size]; \
    memset(name, 0, sizeof(name))

#define ZERO_MEMORY(ptr, size) memset(ptr, 0, size)
#define FILL_MEMORY(ptr, size, value) memset(ptr, value, size)

// ماكرو للتحقق من التوقيع
#define SIGNATURE_CHECK(addr, sig, mask) \
    ({ \
        bool match = true; \
        const uint8_t* bytes = (const uint8_t*)(addr); \
        for (size_t i = 0; i < strlen(mask); ++i) { \
            if (mask[i] == 'x' && bytes[i] != ((const uint8_t*)sig)[i]) { \
                match = false; \
                break; \
            } \
        } \
        match; \
    })

// ماكرو للتحكم في الرؤية
#define EXPORT __attribute__((visibility("default")))
#define HIDDEN __attribute__((visibility("hidden")))
#define INTERNAL __attribute__((visibility("internal")))

// ماكرو للتحسين المتقدم
#define PREFETCH_READ(addr) __builtin_prefetch(addr, 0, 3)
#define PREFETCH_WRITE(addr) __builtin_prefetch(addr, 1, 3)
#define MEMORY_BARRIER() __sync_synchronize()

// ماكرو للتعامل مع الأخطاء
#define TRY_CATCH_BEGIN() \
    do { \
        bool _error_occurred = false;

#define TRY_CATCH_ERROR() \
        _error_occurred = true;

#define TRY_CATCH_END() \
        if (_error_occurred) { \
            LOGE("Error occurred in try-catch block"); \
        } \
    } while(0)

// ماكرو للتحقق من الإصدار
#define VERSION_CHECK(major, minor, patch) \
    ((QYX_VERSION_MAJOR > (major)) || \
     (QYX_VERSION_MAJOR == (major) && QYX_VERSION_MINOR > (minor)) || \
     (QYX_VERSION_MAJOR == (major) && QYX_VERSION_MINOR == (minor) && QYX_VERSION_PATCH >= (patch)))

// ماكرو للتحكم في التجميع الشرطي
#ifdef QYX_FEATURE_WALLHACK
    #define WALLHACK_ENABLED 1
#else
    #define WALLHACK_ENABLED 0
#endif

#ifdef QYX_FEATURE_MAGIC_BULLET
    #define MAGIC_BULLET_ENABLED 1
#else
    #define MAGIC_BULLET_ENABLED 0
#endif

#ifdef QYX_FEATURE_SPEED_HACK
    #define SPEED_HACK_ENABLED 1
#else
    #define SPEED_HACK_ENABLED 0
#endif

// ماكرو للتحكم في السجلات
#if QYX_DEBUG
    #define DEBUG_LOG(fmt, ...) LOGD(fmt, ##__VA_ARGS__)
    #define DEBUG_ONLY(code) code
#else
    #define DEBUG_LOG(fmt, ...) do {} while(0)
    #define DEBUG_ONLY(code) do {} while(0)
#endif

// ماكرو للتحكم في الإنتاج
#ifdef RELEASE_BUILD
    #define RELEASE_ONLY(code) code
    #define DEBUG_ASSERT(condition) do {} while(0)
#else
    #define RELEASE_ONLY(code) do {} while(0)
    #define DEBUG_ASSERT(condition) \
        do { \
            if (!(condition)) { \
                LOGE("Assertion failed: %s", #condition); \
                DEBUG_BREAK(); \
            } \
        } while(0)
#endif

// ماكرو للتوافق مع الإصدارات
#define DEPRECATED __attribute__((deprecated))
#define DEPRECATED_MSG(msg) __attribute__((deprecated(msg)))

// ماكرو للتحكم في التحسين
#define OPTIMIZE_SIZE __attribute__((optimize("Os")))
#define OPTIMIZE_SPEED __attribute__((optimize("O3")))
#define NO_OPTIMIZE __attribute__((optimize("O0")))

// ماكرو للتحكم في المحاذاة
#define ALIGN_TO(n) __attribute__((aligned(n)))
#define PACK_STRUCT __attribute__((packed))

// ماكرو للتحكم في الذاكرة المشتركة
#define THREAD_LOCAL __thread
#define ATOMIC_INT volatile int
#define ATOMIC_BOOL volatile bool

// ماكرو للتحكم في الاستثناءات
#define NOEXCEPT noexcept
#define THROWS(...) throw(__VA_ARGS__)

#endif // MACROS_H

