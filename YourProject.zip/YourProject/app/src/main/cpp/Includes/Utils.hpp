#ifndef UTILS_HPP
#define UTILS_HPP

#include <string>
#include <vector>
#include <cstdint>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/mman.h>
#include <dlfcn.h>
#include "Logger.h"

namespace Utils {

    // دوال للعمل مع الذاكرة
    class Memory {
    public:
        // حماية منطقة في الذاكرة
        static bool Protect(void* addr, size_t len, int prot) {
            uintptr_t pageStart = (uintptr_t)addr & ~(getpagesize() - 1);
            return mprotect((void*)pageStart, len + ((uintptr_t)addr - pageStart), prot) == 0;
        }
        
        // كتابة بيانات في الذاكرة مع الحماية
        static bool Write(void* addr, const void* data, size_t size) {
            if (!Protect(addr, size, PROT_READ | PROT_WRITE | PROT_EXEC)) {
                LOGE("Failed to change memory protection for write");
                return false;
            }
            
            memcpy(addr, data, size);
            
            if (!Protect(addr, size, PROT_READ | PROT_EXEC)) {
                LOGE("Failed to restore memory protection after write");
                return false;
            }
            
            return true;
        }
        
        // قراءة بيانات من الذاكرة
        static bool Read(void* addr, void* buffer, size_t size) {
            try {
                memcpy(buffer, addr, size);
                return true;
            } catch (...) {
                LOGE("Failed to read memory at 0x%lx", (uintptr_t)addr);
                return false;
            }
        }
        
        // البحث عن نمط في الذاكرة
        static uintptr_t FindPattern(uintptr_t start, size_t size, const char* pattern, const char* mask) {
            size_t patternLen = strlen(mask);
            
            for (size_t i = 0; i <= size - patternLen; i++) {
                bool found = true;
                for (size_t j = 0; j < patternLen; j++) {
                    if (mask[j] == 'x' && ((char*)start)[i + j] != pattern[j]) {
                        found = false;
                        break;
                    }
                }
                if (found) {
                    return start + i;
                }
            }
            
            return 0;
        }
        
        // البحث عن نمط بالبايتات
        static uintptr_t FindPatternBytes(uintptr_t start, size_t size, const std::vector<uint8_t>& pattern, const std::string& mask) {
            if (pattern.size() != mask.size()) {
                LOGE("Pattern and mask size mismatch");
                return 0;
            }
            
            for (size_t i = 0; i <= size - pattern.size(); i++) {
                bool found = true;
                for (size_t j = 0; j < pattern.size(); j++) {
                    if (mask[j] == 'x' && ((uint8_t*)start)[i + j] != pattern[j]) {
                        found = false;
                        break;
                    }
                }
                if (found) {
                    return start + i;
                }
            }
            
            return 0;
        }
    };

    // دوال للعمل مع المكتبات
    class Library {
    public:
        // العثور على عنوان قاعدة المكتبة
        static uintptr_t GetBaseAddress(const std::string& libraryName) {
            std::ifstream maps("/proc/self/maps");
            std::string line;
            
            while (std::getline(maps, line)) {
                if (line.find(libraryName) != std::string::npos) {
                    uintptr_t base;
                    if (sscanf(line.c_str(), "%lx", &base) == 1) {
                        return base;
                    }
                }
            }
            
            return 0;
        }
        
        // الحصول على معلومات المكتبة
        static bool GetLibraryInfo(const std::string& libraryName, uintptr_t& base, size_t& size) {
            std::ifstream maps("/proc/self/maps");
            std::string line;
            bool found = false;
            uintptr_t start = 0, end = 0;
            
            while (std::getline(maps, line)) {
                if (line.find(libraryName) != std::string::npos) {
                    uintptr_t lineStart, lineEnd;
                    if (sscanf(line.c_str(), "%lx-%lx", &lineStart, &lineEnd) == 2) {
                        if (!found) {
                            start = lineStart;
                            found = true;
                        }
                        end = lineEnd;
                    }
                }
            }
            
            if (found) {
                base = start;
                size = end - start;
                return true;
            }
            
            return false;
        }
        
        // تحميل مكتبة
        static void* LoadLibrary(const std::string& path) {
            void* handle = dlopen(path.c_str(), RTLD_NOW);
            if (!handle) {
                LOGE("Failed to load library %s: %s", path.c_str(), dlerror());
            }
            return handle;
        }
        
        // الحصول على عنوان دالة
        static void* GetSymbol(void* handle, const std::string& symbol) {
            void* addr = dlsym(handle, symbol.c_str());
            if (!addr) {
                LOGE("Failed to get symbol %s: %s", symbol.c_str(), dlerror());
            }
            return addr;
        }
    };

    // دوال للعمل مع النصوص
    class String {
    public:
        // تقسيم النص
        static std::vector<std::string> Split(const std::string& str, char delimiter) {
            std::vector<std::string> tokens;
            std::stringstream ss(str);
            std::string token;
            
            while (std::getline(ss, token, delimiter)) {
                tokens.push_back(token);
            }
            
            return tokens;
        }
        
        // إزالة المسافات
        static std::string Trim(const std::string& str) {
            size_t start = str.find_first_not_of(" \t\n\r");
            if (start == std::string::npos) return "";
            
            size_t end = str.find_last_not_of(" \t\n\r");
            return str.substr(start, end - start + 1);
        }
        
        // تحويل إلى أحرف صغيرة
        static std::string ToLower(const std::string& str) {
            std::string result = str;
            std::transform(result.begin(), result.end(), result.begin(), ::tolower);
            return result;
        }
        
        // تحويل إلى أحرف كبيرة
        static std::string ToUpper(const std::string& str) {
            std::string result = str;
            std::transform(result.begin(), result.end(), result.begin(), ::toupper);
            return result;
        }
        
        // التحقق من وجود نص فرعي
        static bool Contains(const std::string& str, const std::string& substr) {
            return str.find(substr) != std::string::npos;
        }
        
        // استبدال النص
        static std::string Replace(const std::string& str, const std::string& from, const std::string& to) {
            std::string result = str;
            size_t pos = 0;
            while ((pos = result.find(from, pos)) != std::string::npos) {
                result.replace(pos, from.length(), to);
                pos += to.length();
            }
            return result;
        }
    };

    // دوال للعمل مع الملفات
    class File {
    public:
        // التحقق من وجود الملف
        static bool Exists(const std::string& path) {
            return access(path.c_str(), F_OK) == 0;
        }
        
        // قراءة محتوى الملف
        static std::string ReadAll(const std::string& path) {
            std::ifstream file(path);
            if (!file.is_open()) {
                LOGE("Failed to open file: %s", path.c_str());
                return "";
            }
            
            std::stringstream buffer;
            buffer << file.rdbuf();
            return buffer.str();
        }
        
        // كتابة محتوى إلى الملف
        static bool WriteAll(const std::string& path, const std::string& content) {
            std::ofstream file(path);
            if (!file.is_open()) {
                LOGE("Failed to create file: %s", path.c_str());
                return false;
            }
            
            file << content;
            return true;
        }
        
        // إلحاق محتوى بالملف
        static bool AppendAll(const std::string& path, const std::string& content) {
            std::ofstream file(path, std::ios::app);
            if (!file.is_open()) {
                LOGE("Failed to open file for append: %s", path.c_str());
                return false;
            }
            
            file << content;
            return true;
        }
        
        // الحصول على حجم الملف
        static size_t GetSize(const std::string& path) {
            std::ifstream file(path, std::ios::binary | std::ios::ate);
            if (!file.is_open()) {
                return 0;
            }
            return file.tellg();
        }
    };

    // دوال للعمل مع النظام
    class System {
    public:
        // الحصول على معرف العملية
        static pid_t GetPID() {
            return getpid();
        }
        
        // الحصول على اسم العملية
        static std::string GetProcessName() {
            std::string cmdline = File::ReadAll("/proc/self/cmdline");
            return String::Trim(cmdline);
        }
        
        // التحقق من وجود عملية
        static bool IsProcessRunning(const std::string& processName) {
            std::string cmd = "pgrep " + processName;
            return system(cmd.c_str()) == 0;
        }
        
        // تنفيذ أمر shell
        static std::string ExecuteCommand(const std::string& command) {
            FILE* pipe = popen(command.c_str(), "r");
            if (!pipe) {
                LOGE("Failed to execute command: %s", command.c_str());
                return "";
            }
            
            char buffer[128];
            std::string result;
            while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
                result += buffer;
            }
            
            pclose(pipe);
            return String::Trim(result);
        }
        
        // الحصول على الوقت الحالي بالميلي ثانية
        static uint64_t GetCurrentTimeMs() {
            struct timespec ts;
            clock_gettime(CLOCK_MONOTONIC, &ts);
            return ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
        }
        
        // النوم لفترة محددة
        static void Sleep(uint32_t milliseconds) {
            usleep(milliseconds * 1000);
        }
    };

    // دوال للتحويل
    class Convert {
    public:
        // تحويل البايتات إلى نص سادس عشري
        static std::string BytesToHex(const uint8_t* data, size_t size) {
            std::stringstream ss;
            ss << std::hex << std::uppercase;
            for (size_t i = 0; i < size; ++i) {
                ss << std::setw(2) << std::setfill('0') << static_cast<int>(data[i]);
            }
            return ss.str();
        }
        
        // تحويل النص السادس عشري إلى بايتات
        static std::vector<uint8_t> HexToBytes(const std::string& hex) {
            std::vector<uint8_t> bytes;
            for (size_t i = 0; i < hex.length(); i += 2) {
                std::string byteString = hex.substr(i, 2);
                uint8_t byte = static_cast<uint8_t>(strtol(byteString.c_str(), nullptr, 16));
                bytes.push_back(byte);
            }
            return bytes;
        }
        
        // تحويل العنوان إلى نص
        static std::string AddressToString(uintptr_t addr) {
            std::stringstream ss;
            ss << "0x" << std::hex << std::uppercase << addr;
            return ss.str();
        }
        
        // تحويل النص إلى عنوان
        static uintptr_t StringToAddress(const std::string& str) {
            return strtoul(str.c_str(), nullptr, 16);
        }
    };

    // دوال للتشفير البسيط
    class Crypto {
    public:
        // تشفير XOR بسيط
        static std::string XorEncrypt(const std::string& data, uint8_t key) {
            std::string result = data;
            for (char& c : result) {
                c ^= key;
            }
            return result;
        }
        
        // فك تشفير XOR
        static std::string XorDecrypt(const std::string& data, uint8_t key) {
            return XorEncrypt(data, key); // XOR هو عملية قابلة للعكس
        }
        
        // حساب checksum بسيط
        static uint32_t CalculateChecksum(const uint8_t* data, size_t size) {
            uint32_t checksum = 0;
            for (size_t i = 0; i < size; ++i) {
                checksum += data[i];
            }
            return checksum;
        }
    };

    // دوال للتحقق من الأمان
    class Security {
    public:
        // التحقق من وجود مصحح الأخطاء
        static bool IsDebuggerPresent() {
            std::string status = File::ReadAll("/proc/self/status");
            return String::Contains(status, "TracerPid:\t0") == false;
        }
        
        // التحقق من الجذر
        static bool IsRooted() {
            std::vector<std::string> rootFiles = {
                "/system/app/Superuser.apk",
                "/sbin/su",
                "/system/bin/su",
                "/system/xbin/su",
                "/data/local/xbin/su",
                "/data/local/bin/su"
            };
            
            for (const auto& file : rootFiles) {
                if (File::Exists(file)) {
                    return true;
                }
            }
            
            return false;
        }
        
        // التحقق من المحاكي
        static bool IsEmulator() {
            std::string buildModel = System::ExecuteCommand("getprop ro.product.model");
            std::string buildManufacturer = System::ExecuteCommand("getprop ro.product.manufacturer");
            
            std::vector<std::string> emulatorIndicators = {
                "sdk", "emulator", "simulator", "genymotion", "bluestacks"
            };
            
            for (const auto& indicator : emulatorIndicators) {
                if (String::Contains(String::ToLower(buildModel), indicator) ||
                    String::Contains(String::ToLower(buildManufacturer), indicator)) {
                    return true;
                }
            }
            
            return false;
        }
    };
}

#endif // UTILS_HPP

