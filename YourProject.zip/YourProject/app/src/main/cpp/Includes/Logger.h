#ifndef LOGGER_H
#define LOGGER_H

#include <android/log.h>

// تعريف مستويات السجل
#define LOG_LEVEL_VERBOSE 0
#define LOG_LEVEL_DEBUG   1
#define LOG_LEVEL_INFO    2
#define LOG_LEVEL_WARN    3
#define LOG_LEVEL_ERROR   4
#define LOG_LEVEL_FATAL   5

// تعريف العلامة الافتراضية
#ifndef LOG_TAG
#define LOG_TAG "QYX_MOD"
#endif

// تعريف مستوى السجل الحالي
#ifndef CURRENT_LOG_LEVEL
#ifdef DEBUG
#define CURRENT_LOG_LEVEL LOG_LEVEL_VERBOSE
#else
#define CURRENT_LOG_LEVEL LOG_LEVEL_INFO
#endif
#endif

// ماكرو للتحقق من مستوى السجل
#define LOG_LEVEL_ENABLED(level) (level >= CURRENT_LOG_LEVEL)

// ماكرو أساسي للسجل
#define LOG(level, tag, fmt, ...) \
    do { \
        if (LOG_LEVEL_ENABLED(level)) { \
            __android_log_print(level, tag, fmt, ##__VA_ARGS__); \
        } \
    } while(0)

// ماكرو للسجل مع العلامة الافتراضية
#define LOGV(fmt, ...) LOG(ANDROID_LOG_VERBOSE, LOG_TAG, fmt, ##__VA_ARGS__)
#define LOGD(fmt, ...) LOG(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##__VA_ARGS__)
#define LOGI(fmt, ...) LOG(ANDROID_LOG_INFO, LOG_TAG, fmt, ##__VA_ARGS__)
#define LOGW(fmt, ...) LOG(ANDROID_LOG_WARN, LOG_TAG, fmt, ##__VA_ARGS__)
#define LOGE(fmt, ...) LOG(ANDROID_LOG_ERROR, LOG_TAG, fmt, ##__VA_ARGS__)
#define LOGF(fmt, ...) LOG(ANDROID_LOG_FATAL, LOG_TAG, fmt, ##__VA_ARGS__)

// ماكرو للسجل مع معلومات الملف والسطر
#define LOGV_FL(fmt, ...) LOGV("[%s:%d] " fmt, __FILE__, __LINE__, ##__VA_ARGS__)
#define LOGD_FL(fmt, ...) LOGD("[%s:%d] " fmt, __FILE__, __LINE__, ##__VA_ARGS__)
#define LOGI_FL(fmt, ...) LOGI("[%s:%d] " fmt, __FILE__, __LINE__, ##__VA_ARGS__)
#define LOGW_FL(fmt, ...) LOGW("[%s:%d] " fmt, __FILE__, __LINE__, ##__VA_ARGS__)
#define LOGE_FL(fmt, ...) LOGE("[%s:%d] " fmt, __FILE__, __LINE__, ##__VA_ARGS__)
#define LOGF_FL(fmt, ...) LOGF("[%s:%d] " fmt, __FILE__, __LINE__, ##__VA_ARGS__)

// ماكرو للسجل مع اسم الدالة
#define LOGV_FUNC(fmt, ...) LOGV("[%s] " fmt, __FUNCTION__, ##__VA_ARGS__)
#define LOGD_FUNC(fmt, ...) LOGD("[%s] " fmt, __FUNCTION__, ##__VA_ARGS__)
#define LOGI_FUNC(fmt, ...) LOGI("[%s] " fmt, __FUNCTION__, ##__VA_ARGS__)
#define LOGW_FUNC(fmt, ...) LOGW("[%s] " fmt, __FUNCTION__, ##__VA_ARGS__)
#define LOGE_FUNC(fmt, ...) LOGE("[%s] " fmt, __FUNCTION__, ##__VA_ARGS__)
#define LOGF_FUNC(fmt, ...) LOGF("[%s] " fmt, __FUNCTION__, ##__VA_ARGS__)

// ماكرو لسجل البيانات السادسة عشرية
#define LOG_HEX(level, tag, data, size) \
    do { \
        if (LOG_LEVEL_ENABLED(level)) { \
            char hex_buffer[1024]; \
            int offset = 0; \
            for (int i = 0; i < size && offset < sizeof(hex_buffer) - 3; i++) { \
                offset += snprintf(hex_buffer + offset, sizeof(hex_buffer) - offset, "%02X ", ((unsigned char*)data)[i]); \
            } \
            __android_log_print(level, tag, "HEX[%d]: %s", size, hex_buffer); \
        } \
    } while(0)

#define LOGD_HEX(data, size) LOG_HEX(ANDROID_LOG_DEBUG, LOG_TAG, data, size)
#define LOGI_HEX(data, size) LOG_HEX(ANDROID_LOG_INFO, LOG_TAG, data, size)

// ماكرو لسجل العناوين
#define LOG_ADDR(level, tag, name, addr) \
    LOG(level, tag, "%s: 0x%lx", name, (uintptr_t)addr)

#define LOGD_ADDR(name, addr) LOG_ADDR(ANDROID_LOG_DEBUG, LOG_TAG, name, addr)
#define LOGI_ADDR(name, addr) LOG_ADDR(ANDROID_LOG_INFO, LOG_TAG, name, addr)

// ماكرو لسجل دخول ومغادرة الدوال
#define LOG_ENTER() LOGD_FUNC("ENTER")
#define LOG_EXIT() LOGD_FUNC("EXIT")
#define LOG_EXIT_WITH_VALUE(value) LOGD_FUNC("EXIT with value: %d", value)

// ماكرو للتحقق من الشروط مع السجل
#define LOG_ASSERT(condition, fmt, ...) \
    do { \
        if (!(condition)) { \
            LOGE("ASSERTION FAILED: " #condition " - " fmt, ##__VA_ARGS__); \
        } \
    } while(0)

// ماكرو لسجل الأخطاء مع errno
#define LOG_ERRNO(fmt, ...) \
    LOGE(fmt " (errno: %d, %s)", ##__VA_ARGS__, errno, strerror(errno))

// ماكرو لسجل معلومات النظام
#define LOG_SYSTEM_INFO() \
    do { \
        LOGI("=== QYX MOD SYSTEM INFO ==="); \
        LOGI("Version: %s", QYX_VERSION); \
        LOGI("Build Date: %s", __DATE__ " " __TIME__); \
        LOGI("Target Arch: %s", TARGET_ARCH); \
        LOGI("Debug Mode: %s", DEBUG ? "ON" : "OFF"); \
        LOGI("========================"); \
    } while(0)

// ماكرو لسجل معلومات الذاكرة
#define LOG_MEMORY_INFO(ptr, size) \
    LOGD("Memory: ptr=0x%lx, size=%zu", (uintptr_t)ptr, size)

// ماكرو لسجل الأداء
#define LOG_PERFORMANCE_START(name) \
    struct timespec start_##name; \
    clock_gettime(CLOCK_MONOTONIC, &start_##name); \
    LOGD("PERF_START: %s", #name)

#define LOG_PERFORMANCE_END(name) \
    do { \
        struct timespec end_##name; \
        clock_gettime(CLOCK_MONOTONIC, &end_##name); \
        long diff_ms = (end_##name.tv_sec - start_##name.tv_sec) * 1000 + \
                       (end_##name.tv_nsec - start_##name.tv_nsec) / 1000000; \
        LOGD("PERF_END: %s took %ld ms", #name, diff_ms); \
    } while(0)

#ifdef __cplusplus
extern "C" {
#endif

// دوال مساعدة للسجل
void log_buffer(int level, const char* tag, const char* buffer, size_t size);
void log_stack_trace(int level, const char* tag);
void log_memory_dump(int level, const char* tag, void* addr, size_t size);

#ifdef __cplusplus
}
#endif

#endif // LOGGER_H

