#ifndef OBFUSCATE_H
#define OBFUSCATE_H

#include <string>
#include <cstdint>

// ماكرو لتشفير النصوص في وقت التجميع
#define OBFUSCATE_KEY 0xAB

// تشفير حرف واحد
constexpr char encrypt_char(const char c, int key) {
    return c ^ key;
}

// تشفير نص في وقت التجميع
template<int N, int K>
class obfuscated_string {
private:
    char encrypted[N + 1];
    
public:
    constexpr obfuscated_string(const char* str) : encrypted{} {
        for (int i = 0; i < N; ++i) {
            encrypted[i] = encrypt_char(str[i], K);
        }
        encrypted[N] = '\0';
    }
    
    std::string decrypt() const {
        std::string result;
        result.reserve(N);
        for (int i = 0; i < N; ++i) {
            result += encrypt_char(encrypted[i], K);
        }
        return result;
    }
    
    const char* c_str() const {
        static thread_local char decrypted[N + 1];
        for (int i = 0; i < N; ++i) {
            decrypted[i] = encrypt_char(encrypted[i], K);
        }
        decrypted[N] = '\0';
        return decrypted;
    }
};

// ماكرو لإنشاء نص مشفر
#define OBFUSCATE(str) \
    (obfuscated_string<sizeof(str) - 1, OBFUSCATE_KEY>(str).c_str())

// ماكرو لإنشاء نص مشفر كـ std::string
#define OBFUSCATE_STR(str) \
    (obfuscated_string<sizeof(str) - 1, OBFUSCATE_KEY>(str).decrypt())

// تشفير الأرقام
template<typename T>
constexpr T obfuscate_number(T value, T key = 0x12345678) {
    return value ^ key;
}

#define OBFUSCATE_NUM(num) obfuscate_number(num)

// ماكرو لإخفاء استدعاءات الدوال
#define HIDE_CALL(func, ...) \
    do { \
        volatile auto hidden_func = func; \
        hidden_func(__VA_ARGS__); \
    } while(0)

// ماكرو لإخفاء المتغيرات
#define HIDE_VAR(type, name, value) \
    volatile type name = value; \
    name = name

// تشفير البيانات الثنائية
class BinaryObfuscator {
private:
    static constexpr uint8_t XOR_KEY = 0x5A;
    
public:
    static void encrypt(uint8_t* data, size_t size) {
        for (size_t i = 0; i < size; ++i) {
            data[i] ^= XOR_KEY ^ (i & 0xFF);
        }
    }
    
    static void decrypt(uint8_t* data, size_t size) {
        encrypt(data, size); // XOR هو عملية قابلة للعكس
    }
};

// ماكرو لتشفير البيانات الثنائية
#define OBFUSCATE_BINARY(data, size) BinaryObfuscator::encrypt((uint8_t*)data, size)
#define DEOBFUSCATE_BINARY(data, size) BinaryObfuscator::decrypt((uint8_t*)data, size)

// إخفاء أسماء الدوال والمتغيرات
#define HIDE_SYMBOL __attribute__((visibility("hidden")))
#define INLINE_ALWAYS __attribute__((always_inline)) inline

// ماكرو لإنشاء دوال مخفية
#define HIDDEN_FUNCTION(return_type, name, ...) \
    HIDE_SYMBOL INLINE_ALWAYS return_type name(__VA_ARGS__)

// تشفير عناوين الذاكرة
template<typename T>
class ObfuscatedPointer {
private:
    uintptr_t encrypted_ptr;
    static constexpr uintptr_t KEY = 0xDEADBEEF;
    
public:
    ObfuscatedPointer(T* ptr = nullptr) : encrypted_ptr(reinterpret_cast<uintptr_t>(ptr) ^ KEY) {}
    
    T* get() const {
        return reinterpret_cast<T*>(encrypted_ptr ^ KEY);
    }
    
    void set(T* ptr) {
        encrypted_ptr = reinterpret_cast<uintptr_t>(ptr) ^ KEY;
    }
    
    T* operator->() const { return get(); }
    T& operator*() const { return *get(); }
    operator T*() const { return get(); }
};

// ماكرو لإنشاء مؤشر مشفر
#define OBFUSCATED_PTR(type) ObfuscatedPointer<type>

// تشفير الثوابت المهمة
namespace ObfuscatedConstants {
    constexpr const char* GAME_PACKAGE = OBFUSCATE("com.axlebolt.standoff2");
    constexpr const char* TARGET_LIB = OBFUSCATE("libil2cpp.so");
    constexpr const char* MOD_NAME = OBFUSCATE("QYX_MOD");
    constexpr const char* LOG_TAG = OBFUSCATE("QYX");
    
    // عناوين مهمة (مشفرة)
    constexpr uintptr_t ENCRYPTED_BASE = obfuscate_number<uintptr_t>(0x12345000);
    constexpr size_t ENCRYPTED_SIZE = obfuscate_number<size_t>(0x1000000);
}

// ماكرو لفك تشفير الثوابت
#define GET_GAME_PACKAGE() ObfuscatedConstants::GAME_PACKAGE
#define GET_TARGET_LIB() ObfuscatedConstants::TARGET_LIB
#define GET_MOD_NAME() ObfuscatedConstants::MOD_NAME
#define GET_LOG_TAG() ObfuscatedConstants::LOG_TAG

// إخفاء التحقق من التصحيح
HIDDEN_FUNCTION(bool, is_debugger_present, void) {
    // فحص ملف status للعملية
    FILE* fp = fopen(OBFUSCATE("/proc/self/status"), OBFUSCATE("r"));
    if (!fp) return false;
    
    char line[256];
    bool debugger_found = false;
    
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, OBFUSCATE("TracerPid:"))) {
            int tracer_pid = 0;
            sscanf(line, "TracerPid:\t%d", &tracer_pid);
            if (tracer_pid != 0) {
                debugger_found = true;
                break;
            }
        }
    }
    
    fclose(fp);
    return debugger_found;
}

// إخفاء التحقق من الجذر
HIDDEN_FUNCTION(bool, is_device_rooted, void) {
    const char* root_files[] = {
        OBFUSCATE("/system/app/Superuser.apk"),
        OBFUSCATE("/sbin/su"),
        OBFUSCATE("/system/bin/su"),
        OBFUSCATE("/system/xbin/su"),
        OBFUSCATE("/data/local/xbin/su"),
        OBFUSCATE("/data/local/bin/su"),
        OBFUSCATE("/system/sd/xbin/su"),
        OBFUSCATE("/system/bin/failsafe/su"),
        OBFUSCATE("/data/local/su")
    };
    
    for (const char* file : root_files) {
        if (access(file, F_OK) == 0) {
            return true;
        }
    }
    
    return false;
}

// ماكرو للحماية من التحليل
#define ANTI_DEBUG_CHECK() \
    do { \
        if (is_debugger_present()) { \
            LOGE("Debugger detected! Exiting..."); \
            exit(1); \
        } \
    } while(0)

#define ANTI_ROOT_CHECK() \
    do { \
        if (is_device_rooted()) { \
            LOGW("Root detected!"); \
        } \
    } while(0)

// تشويش التحكم في التدفق
#define OBFUSCATE_FLOW_START() \
    volatile int obf_counter = 0; \
    for (volatile int i = 0; i < 3; ++i) { \
        obf_counter += i; \
        if (obf_counter > 10) break;

#define OBFUSCATE_FLOW_END() \
    }

#endif // OBFUSCATE_H

