#ifndef JNI_HPP
#define JNI_HPP

#include <jni.h>
#include <string>
#include <vector>
#include "../Includes/Logger.h"
#include "../Includes/Utils.hpp"
#include "../Includes/Macros.h"

namespace QYXJni {

    // فئة لإدارة JNI Environment
    class JNIHelper {
    private:
        static JavaVM* javaVM;
        
    public:
        // تعيين JavaVM
        static void SetJavaVM(JavaVM* vm) {
            javaVM = vm;
        }
        
        // الحصول على JavaVM
        static JavaVM* GetJavaVM() {
            return javaVM;
        }
        
        // الحصول على JNI Environment
        static JNIEnv* GetEnv() {
            if (!javaVM) {
                LOGE("JavaVM not set");
                return nullptr;
            }
            
            JNIEnv* env = nullptr;
            int result = javaVM->GetEnv((void**)&env, JNI_VERSION_1_6);
            
            if (result == JNI_EDETACHED) {
                // ربط الخيط الحالي بـ JVM
                result = javaVM->AttachCurrentThread(&env, nullptr);
                if (result != JNI_OK) {
                    LOGE("Failed to attach current thread to JVM");
                    return nullptr;
                }
            } else if (result != JNI_OK) {
                LOGE("Failed to get JNI environment");
                return nullptr;
            }
            
            return env;
        }
        
        // فصل الخيط الحالي من JVM
        static void DetachCurrentThread() {
            if (javaVM) {
                javaVM->DetachCurrentThread();
            }
        }
    };

    // تعريف المتغير الثابت
    JavaVM* JNIHelper::javaVM = nullptr;

    // فئة لإدارة المراجع المحلية
    class LocalRefGuard {
    private:
        JNIEnv* env;
        jobject ref;
        
    public:
        LocalRefGuard(JNIEnv* e, jobject r) : env(e), ref(r) {}
        
        ~LocalRefGuard() {
            if (env && ref) {
                env->DeleteLocalRef(ref);
            }
        }
        
        // منع النسخ
        LocalRefGuard(const LocalRefGuard&) = delete;
        LocalRefGuard& operator=(const LocalRefGuard&) = delete;
    };

    // ماكرو لإدارة المراجع المحلية تلقائياً
    #define AUTO_LOCAL_REF(env, ref) LocalRefGuard _guard_##ref(env, ref)

    // دوال مساعدة للتحويل
    namespace Convert {
        
        // تحويل jstring إلى std::string
        std::string JStringToString(JNIEnv* env, jstring jstr) {
            if (!env || !jstr) {
                return "";
            }
            
            const char* chars = env->GetStringUTFChars(jstr, nullptr);
            if (!chars) {
                LOGE("Failed to get string chars");
                return "";
            }
            
            std::string result(chars);
            env->ReleaseStringUTFChars(jstr, chars);
            
            return result;
        }
        
        // تحويل std::string إلى jstring
        jstring StringToJString(JNIEnv* env, const std::string& str) {
            if (!env) {
                return nullptr;
            }
            
            return env->NewStringUTF(str.c_str());
        }
        
        // تحويل std::vector<std::string> إلى jobjectArray
        jobjectArray StringVectorToJArray(JNIEnv* env, const std::vector<std::string>& vec) {
            if (!env) {
                return nullptr;
            }
            
            jclass stringClass = env->FindClass("java/lang/String");
            if (!stringClass) {
                LOGE("Failed to find String class");
                return nullptr;
            }
            
            jobjectArray result = env->NewObjectArray(vec.size(), stringClass, nullptr);
            if (!result) {
                LOGE("Failed to create object array");
                return nullptr;
            }
            
            for (size_t i = 0; i < vec.size(); ++i) {
                jstring str = StringToJString(env, vec[i]);
                if (str) {
                    env->SetObjectArrayElement(result, i, str);
                    env->DeleteLocalRef(str);
                }
            }
            
            return result;
        }
        
        // تحويل jobjectArray إلى std::vector<std::string>
        std::vector<std::string> JArrayToStringVector(JNIEnv* env, jobjectArray jarray) {
            std::vector<std::string> result;
            
            if (!env || !jarray) {
                return result;
            }
            
            jsize length = env->GetArrayLength(jarray);
            result.reserve(length);
            
            for (jsize i = 0; i < length; ++i) {
                jstring jstr = (jstring)env->GetObjectArrayElement(jarray, i);
                if (jstr) {
                    result.push_back(JStringToString(env, jstr));
                    env->DeleteLocalRef(jstr);
                }
            }
            
            return result;
        }
        
        // تحويل jbyteArray إلى std::vector<uint8_t>
        std::vector<uint8_t> JByteArrayToVector(JNIEnv* env, jbyteArray jarray) {
            std::vector<uint8_t> result;
            
            if (!env || !jarray) {
                return result;
            }
            
            jsize length = env->GetArrayLength(jarray);
            result.resize(length);
            
            env->GetByteArrayRegion(jarray, 0, length, (jbyte*)result.data());
            
            return result;
        }
        
        // تحويل std::vector<uint8_t> إلى jbyteArray
        jbyteArray VectorToJByteArray(JNIEnv* env, const std::vector<uint8_t>& vec) {
            if (!env) {
                return nullptr;
            }
            
            jbyteArray result = env->NewByteArray(vec.size());
            if (!result) {
                LOGE("Failed to create byte array");
                return nullptr;
            }
            
            env->SetByteArrayRegion(result, 0, vec.size(), (const jbyte*)vec.data());
            
            return result;
        }
    }

    // دوال مساعدة للتعامل مع الفئات والطرق
    namespace Reflection {
        
        // العثور على فئة
        jclass FindClass(JNIEnv* env, const std::string& className) {
            if (!env) {
                return nullptr;
            }
            
            jclass clazz = env->FindClass(className.c_str());
            if (!clazz) {
                LOGE("Failed to find class: %s", className.c_str());
                env->ExceptionClear();
            }
            
            return clazz;
        }
        
        // العثور على طريقة
        jmethodID FindMethod(JNIEnv* env, jclass clazz, const std::string& methodName, 
                           const std::string& signature) {
            if (!env || !clazz) {
                return nullptr;
            }
            
            jmethodID method = env->GetMethodID(clazz, methodName.c_str(), signature.c_str());
            if (!method) {
                LOGE("Failed to find method: %s with signature: %s", 
                     methodName.c_str(), signature.c_str());
                env->ExceptionClear();
            }
            
            return method;
        }
        
        // العثور على طريقة ثابتة
        jmethodID FindStaticMethod(JNIEnv* env, jclass clazz, const std::string& methodName, 
                                 const std::string& signature) {
            if (!env || !clazz) {
                return nullptr;
            }
            
            jmethodID method = env->GetStaticMethodID(clazz, methodName.c_str(), signature.c_str());
            if (!method) {
                LOGE("Failed to find static method: %s with signature: %s", 
                     methodName.c_str(), signature.c_str());
                env->ExceptionClear();
            }
            
            return method;
        }
        
        // العثور على حقل
        jfieldID FindField(JNIEnv* env, jclass clazz, const std::string& fieldName, 
                         const std::string& signature) {
            if (!env || !clazz) {
                return nullptr;
            }
            
            jfieldID field = env->GetFieldID(clazz, fieldName.c_str(), signature.c_str());
            if (!field) {
                LOGE("Failed to find field: %s with signature: %s", 
                     fieldName.c_str(), signature.c_str());
                env->ExceptionClear();
            }
            
            return field;
        }
        
        // العثور على حقل ثابت
        jfieldID FindStaticField(JNIEnv* env, jclass clazz, const std::string& fieldName, 
                               const std::string& signature) {
            if (!env || !clazz) {
                return nullptr;
            }
            
            jfieldID field = env->GetStaticFieldID(clazz, fieldName.c_str(), signature.c_str());
            if (!field) {
                LOGE("Failed to find static field: %s with signature: %s", 
                     fieldName.c_str(), signature.c_str());
                env->ExceptionClear();
            }
            
            return field;
        }
    }

    // دوال مساعدة للتعامل مع الاستثناءات
    namespace Exception {
        
        // التحقق من وجود استثناء
        bool CheckException(JNIEnv* env) {
            if (!env) {
                return false;
            }
            
            if (env->ExceptionCheck()) {
                jthrowable exception = env->ExceptionOccurred();
                if (exception) {
                    env->ExceptionDescribe();
                    env->ExceptionClear();
                    env->DeleteLocalRef(exception);
                }
                return true;
            }
            
            return false;
        }
        
        // رمي استثناء
        void ThrowException(JNIEnv* env, const std::string& className, const std::string& message) {
            if (!env) {
                return;
            }
            
            jclass exceptionClass = env->FindClass(className.c_str());
            if (exceptionClass) {
                env->ThrowNew(exceptionClass, message.c_str());
                env->DeleteLocalRef(exceptionClass);
            }
        }
        
        // رمي RuntimeException
        void ThrowRuntimeException(JNIEnv* env, const std::string& message) {
            ThrowException(env, "java/lang/RuntimeException", message);
        }
        
        // رمي IllegalArgumentException
        void ThrowIllegalArgumentException(JNIEnv* env, const std::string& message) {
            ThrowException(env, "java/lang/IllegalArgumentException", message);
        }
    }

    // دوال مساعدة للتعامل مع Context
    namespace Context {
        
        // الحصول على Application Context
        jobject GetApplicationContext(JNIEnv* env, jobject context) {
            if (!env || !context) {
                return nullptr;
            }
            
            jclass contextClass = env->GetObjectClass(context);
            if (!contextClass) {
                return nullptr;
            }
            
            jmethodID getApplicationContextMethod = env->GetMethodID(contextClass, 
                "getApplicationContext", "()Landroid/content/Context;");
            
            if (!getApplicationContextMethod) {
                env->DeleteLocalRef(contextClass);
                return nullptr;
            }
            
            jobject appContext = env->CallObjectMethod(context, getApplicationContextMethod);
            env->DeleteLocalRef(contextClass);
            
            return appContext;
        }
        
        // الحصول على Package Name
        std::string GetPackageName(JNIEnv* env, jobject context) {
            if (!env || !context) {
                return "";
            }
            
            jclass contextClass = env->GetObjectClass(context);
            if (!contextClass) {
                return "";
            }
            
            jmethodID getPackageNameMethod = env->GetMethodID(contextClass, 
                "getPackageName", "()Ljava/lang/String;");
            
            if (!getPackageNameMethod) {
                env->DeleteLocalRef(contextClass);
                return "";
            }
            
            jstring packageName = (jstring)env->CallObjectMethod(context, getPackageNameMethod);
            env->DeleteLocalRef(contextClass);
            
            if (!packageName) {
                return "";
            }
            
            std::string result = Convert::JStringToString(env, packageName);
            env->DeleteLocalRef(packageName);
            
            return result;
        }
    }

    // دوال مساعدة للتعامل مع Toast
    namespace Toast {
        
        // إظهار Toast message
        void ShowToast(JNIEnv* env, jobject context, const std::string& message, bool longDuration = false) {
            if (!env || !context) {
                return;
            }
            
            // العثور على فئة Toast
            jclass toastClass = env->FindClass("android/widget/Toast");
            if (!toastClass) {
                return;
            }
            
            // العثور على طريقة makeText
            jmethodID makeTextMethod = env->GetStaticMethodID(toastClass, "makeText", 
                "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
            
            if (!makeTextMethod) {
                env->DeleteLocalRef(toastClass);
                return;
            }
            
            // تحويل الرسالة إلى jstring
            jstring jmessage = Convert::StringToJString(env, message);
            if (!jmessage) {
                env->DeleteLocalRef(toastClass);
                return;
            }
            
            // تحديد مدة العرض
            jint duration = longDuration ? 1 : 0; // LENGTH_LONG : LENGTH_SHORT
            
            // إنشاء Toast
            jobject toast = env->CallStaticObjectMethod(toastClass, makeTextMethod, 
                context, jmessage, duration);
            
            if (toast) {
                // العثور على طريقة show
                jmethodID showMethod = env->GetMethodID(toastClass, "show", "()V");
                if (showMethod) {
                    env->CallVoidMethod(toast, showMethod);
                }
                env->DeleteLocalRef(toast);
            }
            
            env->DeleteLocalRef(jmessage);
            env->DeleteLocalRef(toastClass);
        }
    }
}

#endif // JNI_HPP

