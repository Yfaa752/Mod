#ifndef MENU_HPP
#define MENU_HPP

#include <jni.h>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include "../Includes/Logger.h"
#include "../Includes/Utils.hpp"
#include "../Includes/Macros.h"

namespace QYXMenu {

    // هيكل لتمثيل ميزة واحدة
    struct Feature {
        int id;
        std::string name;
        std::string description;
        std::string category;
        bool enabled;
        bool requiresSystem;
        std::function<void(bool)> callback;
        
        Feature() : id(-1), enabled(false), requiresSystem(false) {}
        
        Feature(int _id, const std::string& _name, const std::string& _desc, 
                const std::string& _category, bool _requiresSystem = true)
            : id(_id), name(_name), description(_desc), category(_category), 
              enabled(false), requiresSystem(_requiresSystem) {}
    };

    // فئة لإدارة القائمة والميزات
    class MenuManager {
    private:
        static MenuManager* instance;
        std::map<int, Feature> features;
        bool systemEnabled;
        bool initialized;
        
        // منع النسخ والإسناد
        MenuManager() : systemEnabled(false), initialized(false) {}
        MenuManager(const MenuManager&) = delete;
        MenuManager& operator=(const MenuManager&) = delete;
        
    public:
        // الحصول على المثيل الوحيد
        static MenuManager* GetInstance() {
            if (!instance) {
                instance = new MenuManager();
            }
            return instance;
        }
        
        // تهيئة النظام
        bool Initialize() {
            if (initialized) {
                return true;
            }
            
            LOGI("Initializing QYX Menu System...");
            
            // تسجيل الميزات
            RegisterFeatures();
            
            initialized = true;
            LOGI("QYX Menu System initialized successfully");
            return true;
        }
        
        // تسجيل الميزات
        void RegisterFeatures() {
            // الميزة الأساسية - تفعيل النظام
            RegisterFeature(0, "Enable QYX", "Master toggle for QYX system", "system", false);
            
            // ميزات القتال
            RegisterFeature(1, "Wallhack", "See through walls and obstacles", "visual");
            RegisterFeature(2, "Magic Bullet", "Bullets go through walls", "combat");
            RegisterFeature(7, "Auto Fire / Aim Assist", "Automatically fire at enemies", "combat");
            RegisterFeature(5, "Fast Switch Gun", "Instantly switch weapons", "combat");
            RegisterFeature(9, "Fast Auto Reload", "Reload weapons faster", "combat");
            
            // ميزات الحركة
            RegisterFeature(3, "Player Speed", "Increase movement speed", "movement");
            RegisterFeature(8, "Weapon Run Speed", "Move faster with weapons", "movement");
            
            // ميزات بصرية
            RegisterFeature(4, "ESP Line/Box", "Show enemy positions", "visual");
            
            // ميزات أخرى
            RegisterFeature(6, "Reset Guest", "Reset guest account", "utility");
            
            LOGI("Registered %zu features", features.size());
        }
        
        // تسجيل ميزة واحدة
        void RegisterFeature(int id, const std::string& name, const std::string& description, 
                           const std::string& category, bool requiresSystem = true) {
            Feature feature(id, name, description, category, requiresSystem);
            
            // تعيين callback للميزة
            feature.callback = [this, id](bool enabled) {
                this->OnFeatureToggle(id, enabled);
            };
            
            features[id] = feature;
            LOGD("Registered feature: %s (ID: %d)", name.c_str(), id);
        }
        
        // تفعيل/إلغاء تفعيل ميزة
        bool ToggleFeature(int featureId, bool enabled) {
            auto it = features.find(featureId);
            if (it == features.end()) {
                LOGE("Feature not found: %d", featureId);
                return false;
            }
            
            Feature& feature = it->second;
            
            // التحقق من متطلبات النظام
            if (feature.requiresSystem && !systemEnabled && featureId != 0) {
                LOGW("Feature %s requires system to be enabled first", feature.name.c_str());
                return false;
            }
            
            // تحديث حالة الميزة
            feature.enabled = enabled;
            
            // استدعاء callback
            if (feature.callback) {
                feature.callback(enabled);
            }
            
            LOGI("Feature %s %s", feature.name.c_str(), enabled ? "enabled" : "disabled");
            return true;
        }
        
        // معالج تفعيل الميزات
        void OnFeatureToggle(int featureId, bool enabled) {
            switch (featureId) {
                case 0: // Enable QYX System
                    systemEnabled = enabled;
                    if (enabled) {
                        LOGI("QYX System activated");
                        // تهيئة إضافية للنظام
                        InitializeGameHooks();
                    } else {
                        LOGI("QYX System deactivated");
                        // تنظيف النظام
                        CleanupGameHooks();
                    }
                    break;
                    
                case 1: // Wallhack
                    ApplyWallhack(enabled);
                    break;
                    
                case 2: // Magic Bullet
                    ApplyMagicBullet(enabled);
                    break;
                    
                case 3: // Player Speed
                    ApplyPlayerSpeed(enabled);
                    break;
                    
                case 4: // ESP
                    ApplyESP(enabled);
                    break;
                    
                case 5: // Fast Switch Gun
                    ApplyFastSwitchGun(enabled);
                    break;
                    
                case 6: // Reset Guest
                    if (enabled) {
                        ResetGuestAccount();
                    }
                    break;
                    
                case 7: // Auto Fire
                    ApplyAutoFire(enabled);
                    break;
                    
                case 8: // Weapon Run Speed
                    ApplyWeaponRunSpeed(enabled);
                    break;
                    
                case 9: // Fast Auto Reload
                    ApplyFastAutoReload(enabled);
                    break;
                    
                default:
                    LOGW("Unknown feature ID: %d", featureId);
                    break;
            }
        }
        
        // الحصول على قائمة الميزات
        std::vector<std::string> GetFeatureList() {
            std::vector<std::string> featureList;
            for (const auto& pair : features) {
                featureList.push_back(pair.second.name);
            }
            return featureList;
        }
        
        // الحصول على ميزة بالمعرف
        Feature* GetFeature(int featureId) {
            auto it = features.find(featureId);
            return (it != features.end()) ? &it->second : nullptr;
        }
        
        // الحصول على حالة الميزة
        bool IsFeatureEnabled(int featureId) {
            Feature* feature = GetFeature(featureId);
            return feature ? feature->enabled : false;
        }
        
        // الحصول على عدد الميزات
        size_t GetFeatureCount() const {
            return features.size();
        }
        
        // التحقق من تهيئة النظام
        bool IsInitialized() const {
            return initialized;
        }
        
        // التحقق من تفعيل النظام
        bool IsSystemEnabled() const {
            return systemEnabled;
        }
        
    private:
        // تهيئة hooks للعبة
        void InitializeGameHooks() {
            LOGI("Initializing game hooks...");
            
            // البحث عن المكتبة المستهدفة
            uintptr_t libBase = Utils::Library::GetBaseAddress("libil2cpp.so");
            if (!libBase) {
                LOGE("Failed to find target library");
                return;
            }
            
            LOGI("Target library found at: 0x%lx", libBase);
            
            // تهيئة hooks إضافية حسب الحاجة
            // ...
        }
        
        // تنظيف hooks
        void CleanupGameHooks() {
            LOGI("Cleaning up game hooks...");
            
            // إلغاء تفعيل جميع الميزات
            for (auto& pair : features) {
                if (pair.first != 0 && pair.second.enabled) {
                    ToggleFeature(pair.first, false);
                }
            }
        }
        
        // تطبيق ميزة Wallhack
        void ApplyWallhack(bool enabled) {
            LOGD("Applying Wallhack: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق Wallhack
        }
        
        // تطبيق ميزة Magic Bullet
        void ApplyMagicBullet(bool enabled) {
            LOGD("Applying Magic Bullet: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق Magic Bullet
        }
        
        // تطبيق ميزة Player Speed
        void ApplyPlayerSpeed(bool enabled) {
            LOGD("Applying Player Speed: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق زيادة السرعة
        }
        
        // تطبيق ميزة ESP
        void ApplyESP(bool enabled) {
            LOGD("Applying ESP: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق ESP
        }
        
        // تطبيق ميزة Fast Switch Gun
        void ApplyFastSwitchGun(bool enabled) {
            LOGD("Applying Fast Switch Gun: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق التبديل السريع
        }
        
        // تطبيق ميزة Auto Fire
        void ApplyAutoFire(bool enabled) {
            LOGD("Applying Auto Fire: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق الإطلاق التلقائي
        }
        
        // تطبيق ميزة Weapon Run Speed
        void ApplyWeaponRunSpeed(bool enabled) {
            LOGD("Applying Weapon Run Speed: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق سرعة الجري مع السلاح
        }
        
        // تطبيق ميزة Fast Auto Reload
        void ApplyFastAutoReload(bool enabled) {
            LOGD("Applying Fast Auto Reload: %s", enabled ? "ON" : "OFF");
            // تنفيذ منطق إعادة التحميل السريعة
        }
        
        // إعادة تعيين حساب الضيف
        void ResetGuestAccount() {
            LOGI("Resetting guest account...");
            // تنفيذ منطق إعادة تعيين الحساب
        }
    };

    // تعريف المثيل الثابت
    MenuManager* MenuManager::instance = nullptr;

    // دوال مساعدة للوصول السريع
    inline MenuManager* GetMenuManager() {
        return MenuManager::GetInstance();
    }
    
    inline bool InitializeMenu() {
        return GetMenuManager()->Initialize();
    }
    
    inline bool ToggleFeature(int featureId, bool enabled) {
        return GetMenuManager()->ToggleFeature(featureId, enabled);
    }
    
    inline bool IsFeatureEnabled(int featureId) {
        return GetMenuManager()->IsFeatureEnabled(featureId);
    }
    
    inline std::vector<std::string> GetFeatureList() {
        return GetMenuManager()->GetFeatureList();
    }

    // دوال للتكامل مع JNI
    namespace JNI {
        // تحويل std::vector<std::string> إلى jobjectArray
        inline jobjectArray StringVectorToJArray(JNIEnv* env, const std::vector<std::string>& vec) {
            jclass stringClass = env->FindClass("java/lang/String");
            jobjectArray result = env->NewObjectArray(vec.size(), stringClass, nullptr);
            
            for (size_t i = 0; i < vec.size(); ++i) {
                jstring str = env->NewStringUTF(vec[i].c_str());
                env->SetObjectArrayElement(result, i, str);
                env->DeleteLocalRef(str);
            }
            
            return result;
        }
        
        // تحويل jstring إلى std::string
        inline std::string JStringToString(JNIEnv* env, jstring jstr) {
            if (!jstr) return "";
            
            const char* chars = env->GetStringUTFChars(jstr, nullptr);
            std::string result(chars);
            env->ReleaseStringUTFChars(jstr, chars);
            
            return result;
        }
    }
}

#endif // MENU_HPP

