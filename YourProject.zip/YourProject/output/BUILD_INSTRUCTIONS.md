# تعليمات بناء مشروع QYX Mod

## نظرة عامة
هذا الدليل يوضح كيفية بناء مشروع QYX Mod من الكود المصدري إلى الملفات النهائية القابلة للاستخدام.

## المتطلبات المسبقة

### البرامج المطلوبة
1. **Android Studio** (الإصدار 4.2 أو أحدث)
   - تحميل من: https://developer.android.com/studio
   
2. **Android NDK** (الإصدار 25.2.9519653)
   - يمكن تثبيته من Android Studio SDK Manager
   
3. **CMake** (الإصدار 3.18.1 أو أحدث)
   - يمكن تثبيته من Android Studio SDK Manager
   
4. **Java Development Kit (JDK)** (الإصدار 8 أو أحدث)
   - تحميل من: https://adoptopenjdk.net/

### إعداد البيئة
```bash
# تعيين متغيرات البيئة
export ANDROID_HOME=/path/to/android/sdk
export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/25.2.9519653
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

## خطوات البناء

### 1. إعداد المشروع
```bash
# استنساخ أو نسخ المشروع
cd /path/to/YourProject

# التأكد من وجود جميع الملفات
ls -la app/src/main/cpp/
ls -la app/src/main/java/com/android/support/
ls -la app/src/main/assets/
```

### 2. فتح المشروع في Android Studio
1. افتح Android Studio
2. اختر "Open an existing Android Studio project"
3. حدد مجلد `YourProject`
4. انتظر مزامنة Gradle (قد تستغرق عدة دقائق)

### 3. إعداد SDK و NDK
1. اذهب إلى File → Project Structure
2. في تبويب SDK Location:
   - تأكد من تعيين Android SDK location
   - تأكد من تعيين Android NDK location
3. في تبويب Modules → app:
   - تأكد من Compile Sdk Version: 34
   - تأكد من Build Tools Version: 34.0.0

### 4. البناء من Android Studio
1. اختر Build → Clean Project
2. اختر Build → Rebuild Project
3. اختر Build → Build Bundle(s) / APK(s) → Build APK(s)

### 5. البناء من سطر الأوامر
```bash
# الانتقال إلى مجلد المشروع
cd YourProject

# تنظيف المشروع
./gradlew clean

# بناء APK للتصحيح
./gradlew assembleDebug

# بناء APK للإصدار النهائي (اختياري)
./gradlew assembleRelease

# تشغيل المهام المخصصة
./gradlew buildComplete
```

## الملفات النهائية

### مواقع الملفات بعد البناء
```
YourProject/
├── app/build/outputs/apk/debug/
│   └── qyx_mod_1.0.0_debug.apk
├── app/build/intermediates/cmake/debug/obj/
│   ├── arm64-v8a/libqyx_mod.so
│   └── armeabi-v7a/libqyx_mod.so
└── output/
    ├── libs/
    │   ├── arm64-v8a/libqyx_mod.so
    │   └── armeabi-v7a/libqyx_mod.so
    └── assets/
        └── qyx_config.xml
```

### نسخ الملفات النهائية
```bash
# نسخ المكتبات الأصلية
cp app/build/intermediates/cmake/debug/obj/arm64-v8a/libqyx_mod.so output/libs/arm64-v8a/
cp app/build/intermediates/cmake/debug/obj/armeabi-v7a/libqyx_mod.so output/libs/armeabi-v7a/

# نسخ ملفات الأصول
cp app/src/main/assets/qyx_config.xml output/assets/

# نسخ APK
cp app/build/outputs/apk/debug/app-debug.apk output/qyx_mod_1.0.0_debug.apk
```

## التحقق من البناء

### فحص المكتبة الأصلية
```bash
# التحقق من وجود المكتبة
file output/libs/arm64-v8a/libqyx_mod.so
file output/libs/armeabi-v7a/libqyx_mod.so

# فحص الرموز المصدرة
nm -D output/libs/arm64-v8a/libqyx_mod.so | grep Java

# فحص التبعيات
objdump -p output/libs/arm64-v8a/libqyx_mod.so | grep NEEDED
```

### فحص APK
```bash
# فحص محتويات APK
unzip -l output/qyx_mod_1.0.0_debug.apk

# التحقق من وجود المكتبات الأصلية
unzip -l output/qyx_mod_1.0.0_debug.apk | grep "\.so$"

# التحقق من ملفات الأصول
unzip -l output/qyx_mod_1.0.0_debug.apk | grep assets
```

## استكشاف الأخطاء وإصلاحها

### مشاكل شائعة وحلولها

#### 1. خطأ في مزامنة Gradle
```
Error: Could not find com.android.tools.build:gradle:8.1.2
```
**الحل:**
- تأكد من اتصال الإنترنت
- حدّث Android Studio إلى أحدث إصدار
- امسح cache: File → Invalidate Caches and Restart

#### 2. خطأ في NDK
```
Error: NDK not configured
```
**الحل:**
```bash
# في local.properties
ndk.dir=/path/to/android/ndk/25.2.9519653
sdk.dir=/path/to/android/sdk
```

#### 3. خطأ في CMake
```
Error: CMake was unable to find a build program
```
**الحل:**
- ثبت CMake من SDK Manager
- تأكد من إصدار CMake 3.18.1+

#### 4. خطأ في التوقيع
```
Error: Failed to read key from keystore
```
**الحل:**
- للتصحيح: استخدم debug keystore الافتراضي
- للإصدار: أنشئ keystore جديد

### سجلات التصحيح
```bash
# عرض سجلات البناء
./gradlew assembleDebug --info

# عرض سجلات CMake
./gradlew assembleDebug --debug | grep -i cmake

# فحص تبعيات Gradle
./gradlew dependencies
```

## التحسين والتخصيص

### تحسين حجم APK
```gradle
// في app/build.gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt')
        }
    }
}
```

### تخصيص المعماريات
```gradle
// بناء معمارية واحدة فقط
android {
    splits {
        abi {
            enable true
            reset()
            include 'arm64-v8a'  // أو 'armeabi-v7a'
            universalApk false
        }
    }
}
```

### إعدادات التوقيع للإصدار النهائي
```gradle
// في app/build.gradle
android {
    signingConfigs {
        release {
            storeFile file('release.keystore')
            storePassword 'your_store_password'
            keyAlias 'your_key_alias'
            keyPassword 'your_key_password'
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

## الاختبار

### اختبار المكتبة الأصلية
```bash
# تشغيل اختبارات الوحدة
./gradlew testDebugUnitTest

# اختبار على جهاز
adb install output/qyx_mod_1.0.0_debug.apk
adb logcat | grep QYX_MOD
```

### اختبار الميزات
1. ثبت APK على جهاز Android
2. شغّل التطبيق
3. فعّل "Enable QYX"
4. اختبر كل ميزة على حدة
5. تحقق من السجلات

## النشر والتوزيع

### إعداد الإصدار النهائي
1. حدّث رقم الإصدار في `build.gradle`
2. أنشئ keystore للتوقيع
3. ابنِ APK للإصدار النهائي
4. اختبر APK على أجهزة متعددة

### التحقق النهائي
```bash
# فحص APK النهائي
aapt dump badging output/qyx_mod_1.0.0_release.apk
apkanalyzer apk summary output/qyx_mod_1.0.0_release.apk
```

---

**ملاحظة**: تأكد من اتباع جميع الخطوات بالترتيب للحصول على أفضل النتائج.

